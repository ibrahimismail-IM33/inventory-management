-- Lotline: multi-tenant inventory (own catalog per company)

create table if not exists companies (
  id text primary key,
  name text not null,
  created_by text not null,
  seeded boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists company_members (
  company_id text not null references companies (id) on delete cascade,
  user_id text not null,
  role text not null default 'admin',
  created_at timestamptz not null default now(),
  primary key (company_id, user_id)
);
create unique index if not exists company_members_user_unique on company_members (user_id);
create index if not exists company_members_company_idx on company_members (company_id);

create table if not exists locations (
  id text primary key,
  company_id text not null references companies (id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now()
);
create index if not exists locations_company_idx on locations (company_id);

create table if not exists items (
  id text primary key,
  company_id text not null references companies (id) on delete cascade,
  sku text not null,
  name text not null,
  category text not null,
  barcode text,
  unit text not null default 'ea',
  cost numeric(12, 2) not null default 0,
  has_expiry boolean not null default false,
  return_to_factory boolean not null default true,
  status text not null default 'active',
  created_at timestamptz not null default now(),
  unique (company_id, sku)
);
create index if not exists items_company_sku_idx on items (company_id, sku);
create index if not exists items_company_name_idx on items (company_id, lower(name));
create index if not exists items_company_cat_idx on items (company_id, category);

create table if not exists lots (
  id text primary key,
  company_id text not null references companies (id) on delete cascade,
  item_id text not null references items (id) on delete cascade,
  lot_code text not null,
  expires_at date,
  status text not null default 'ok',
  created_at timestamptz not null default now(),
  unique (company_id, item_id, lot_code)
);
create index if not exists lots_company_expires_idx on lots (company_id, expires_at);
create index if not exists lots_item_idx on lots (item_id);
create index if not exists lots_company_status_idx on lots (company_id, status);

create table if not exists stock (
  company_id text not null references companies (id) on delete cascade,
  lot_id text not null references lots (id) on delete cascade,
  location_id text not null references locations (id) on delete cascade,
  qty integer not null default 0,
  primary key (lot_id, location_id)
);
create index if not exists stock_company_idx on stock (company_id);

create table if not exists stock_movements (
  id text primary key,
  company_id text not null references companies (id) on delete cascade,
  item_id text not null,
  lot_id text not null,
  location_id text not null,
  kind text not null,
  qty integer not null,
  reason text,
  actor_id text not null,
  created_at timestamptz not null default now()
);
create index if not exists movements_company_idx on stock_movements (company_id, created_at desc);
create index if not exists movements_item_idx on stock_movements (item_id, created_at desc);

create table if not exists buyer_returns (
  id text primary key,
  company_id text not null references companies (id) on delete cascade,
  item_id text not null,
  lot_id text not null,
  location_id text not null,
  qty integer not null,
  damage_code text not null,
  buyer_name text,
  order_ref text,
  decision text not null default 'refund',
  outcome text not null default 'quarantine',
  factory_return_id text,
  notes text,
  actor_id text not null,
  created_at timestamptz not null default now()
);
create index if not exists buyer_returns_company_idx on buyer_returns (company_id, created_at desc);

create table if not exists factory_returns (
  id text primary key,
  company_id text not null references companies (id) on delete cascade,
  vendor_name text not null,
  rma_number text,
  status text not null default 'draft',
  credit_amount numeric(12, 2),
  notes text,
  actor_id text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists factory_returns_company_idx on factory_returns (company_id, created_at desc);

create table if not exists factory_return_lines (
  id text primary key,
  factory_return_id text not null references factory_returns (id) on delete cascade,
  company_id text not null,
  item_id text not null,
  lot_id text not null,
  location_id text not null,
  qty integer not null,
  damage_code text not null
);
create index if not exists factory_return_lines_rtv_idx on factory_return_lines (factory_return_id);
