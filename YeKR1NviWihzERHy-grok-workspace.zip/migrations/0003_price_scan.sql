alter table items add column if not exists sell_price numeric(12, 2) not null default 0;

create table if not exists scan_events (
  id text primary key,
  company_id text not null references companies (id) on delete cascade,
  user_id text not null,
  barcode text not null,
  consumed boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists scan_events_company_open_idx
  on scan_events (company_id, consumed, created_at desc);
