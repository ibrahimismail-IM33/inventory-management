import { chromium } from "playwright";

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
page.on("console", (m) => {
  if (m.type() === "error") console.log("CONSOLE", m.text());
});
page.on("pageerror", (e) => console.log("PAGEERROR", e.message));

async function shot(name) {
  await page.screenshot({
    path: `/workspace/screenshots/${name}.png`,
    fullPage: true,
  });
  console.log("SHOT", name, "url=", page.url());
}

try {
  await page.goto("http://127.0.0.1:8080/login", { waitUntil: "networkidle" });
  await page.waitForTimeout(800);
  await shot("01-login");

  const email = `qa${Date.now()}@lotline.test`;
  await page.getByRole("button", { name: /New company/i }).click();
  await page.locator("#name").fill("North Dock");
  await page.locator("#email").fill(email);
  await page.locator("#password").fill("warehouse1");
  await page.getByRole("button", { name: /Create workspace/i }).click();

  try {
    await page.waitForURL((u) => u.pathname === "/", { timeout: 25000 });
  } catch {
    console.log("did not navigate, current", page.url());
    await shot("02-after-signup-stuck");
  }

  await page.waitForTimeout(3000);
  await shot("02-overview");
  console.log("BODY", (await page.locator("body").innerText()).slice(0, 600));

  for (const [path, name] of [
    ["/catalog", "03-catalog"],
    ["/expiry", "04-expiry"],
    ["/returns", "05-returns"],
    ["/factory", "06-factory"],
  ]) {
    await page.goto(`http://127.0.0.1:8080${path}`, { waitUntil: "networkidle" });
    await page.waitForTimeout(1500);
    await shot(name);
    console.log(name, (await page.locator("body").innerText()).slice(0, 250));
  }

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("http://127.0.0.1:8080/", { waitUntil: "networkidle" });
  await page.waitForTimeout(1500);
  await shot("07-mobile");
} finally {
  await browser.close();
}
