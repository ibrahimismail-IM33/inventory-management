import { useState } from "react";
import { toast } from "sonner";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createItem } from "@/lib/inventory";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function UnknownBarcode({
  barcode,
  onClose,
  onCreated,
}: {
  barcode: string | null;
  onClose: () => void;
  onCreated?: (id: string, sku: string) => void;
}) {
  const qc = useQueryClient();
  const [sku, setSku] = useState("");
  const [name, setName] = useState("");
  const [cost, setCost] = useState("");
  const [sellPrice, setSellPrice] = useState("");
  const [qty, setQty] = useState("0");
  const [hasExpiry, setHasExpiry] = useState(false);
  const [expiresAt, setExpiresAt] = useState("");

  const mut = useMutation({
    mutationFn: () =>
      createItem({
        data: {
          sku: sku || barcode || "",
          name,
          category: "General",
          barcode: barcode ?? undefined,
          cost: Number(cost),
          sellPrice: Number(sellPrice),
          hasExpiry,
          openingQty: Number(qty),
          expiresAt: hasExpiry ? expiresAt : null,
        },
      }),
    onSuccess: (res) => {
      toast.success("SKU created from barcode");
      void qc.invalidateQueries({ queryKey: ["items"] });
      onCreated?.(res.id, (sku || barcode || "").toUpperCase());
      onClose();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog
      open={Boolean(barcode)}
      onOpenChange={(v) => {
        if (!v) onClose();
      }}
    >
      <DialogContent title="Unknown barcode">
        <p className="mb-3 text-sm text-muted">
          <span className="font-mono text-fg">{barcode}</span> is not in this company. Create a
          SKU, or ignore.
        </p>
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            mut.mutate();
          }}
        >
          <div className="space-y-1.5">
            <Label htmlFor="u-sku">SKU</Label>
            <Input id="u-sku" value={sku} onChange={(e) => setSku(e.target.value)} placeholder={barcode ?? ""} className="font-mono" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="u-name">Name</Label>
            <Input id="u-name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="u-cost">Cost</Label>
              <Input id="u-cost" type="number" min={0} step="0.01" value={cost} onChange={(e) => setCost(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="u-sell">Sell price</Label>
              <Input id="u-sell" type="number" min={0} step="0.01" value={sellPrice} onChange={(e) => setSellPrice(e.target.value)} />
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={hasExpiry} onChange={(e) => setHasExpiry(e.target.checked)} />
            First lot has an expiry date
          </label>
          {hasExpiry && (
            <div className="space-y-1.5">
              <Label htmlFor="u-exp">Expiry</Label>
              <Input id="u-exp" type="date" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} required />
            </div>
          )}
          <div className="space-y-1.5">
            <Label htmlFor="u-qty">Opening qty</Label>
            <Input id="u-qty" type="number" min={0} value={qty} onChange={(e) => setQty(e.target.value)} />
          </div>
          <div className="flex gap-2">
            <Button type="button" variant="secondary" className="flex-1" onClick={onClose}>
              Ignore
            </Button>
            <Button type="submit" className="flex-1" disabled={mut.isPending}>
              Create SKU
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
