import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import {
  ArrowLeftRight,
  Boxes,
  Factory,
  LayoutDashboard,
  PackageSearch,
  RotateCcw,
  ScanBarcode,
  Timer,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { UserButton } from "@/lib/auth/gates";
import { getWorkspaceOverview } from "@/lib/inventory";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Overview", icon: LayoutDashboard },
  { to: "/catalog", label: "Catalog", icon: PackageSearch },
  { to: "/moves", label: "In / out", icon: ArrowLeftRight },
  { to: "/scan", label: "Scan", icon: ScanBarcode },
  { to: "/expiry", label: "Expiry", icon: Timer },
  { to: "/returns", label: "Buyer returns", icon: RotateCcw },
  { to: "/factory", label: "Factory RTV", icon: Factory },
] as const;

export function AppShell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const overview = useQuery({
    queryKey: ["overview"],
    queryFn: () => getWorkspaceOverview(),
  });
  const company = overview.data?.workspace.companyName ?? "Your warehouse";

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh max-w-[1400px]">
        <aside className="hidden w-60 shrink-0 flex-col border-r border-border px-4 py-6 md:flex">
          <Brand />
          <p className="mt-6 text-[11px] font-medium tracking-[0.16em] text-subtle uppercase">
            {company}
          </p>
          <nav className="mt-4 flex flex-col gap-1">
            {NAV.map((item) => (
              <NavLink key={item.to} {...item} active={isActive(pathname, item.to)} />
            ))}
          </nav>
          <div className="mt-auto border-t border-border pt-4">
            <UserButton />
          </div>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="flex items-center justify-between gap-3 border-b border-border px-4 py-3 md:hidden">
            <Brand compact />
            <UserButton />
          </header>
          <nav className="flex gap-1 overflow-x-auto border-b border-border px-2 py-2 md:hidden">
            {NAV.map((item) => (
              <NavLink key={item.to} {...item} active={isActive(pathname, item.to)} compact />
            ))}
          </nav>
          <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  );
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <span className="grid size-9 place-items-center rounded-sm border border-border bg-elevated">
        <Boxes className="size-4 text-accent" />
      </span>
      {!compact && (
        <span className="font-display text-xl leading-none tracking-tight">Lotline</span>
      )}
    </Link>
  );
}

function NavLink({
  to,
  label,
  icon: Icon,
  active,
  compact,
}: {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
  active: boolean;
  compact?: boolean;
}) {
  return (
    <Link
      to={to}
      className={cn(
        "flex items-center gap-2 rounded-sm px-3 text-sm transition-colors duration-150",
        compact ? "h-10 shrink-0" : "h-11",
        active ? "bg-elevated text-fg" : "text-muted hover:bg-elevated/60 hover:text-fg",
      )}
    >
      <Icon className="size-4 shrink-0" />
      {label}
    </Link>
  );
}

function isActive(pathname: string, to: string) {
  if (to === "/") return pathname === "/";
  return pathname === to || pathname.startsWith(`${to}/`);
}
