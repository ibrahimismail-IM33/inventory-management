import { useEffect, useId, useRef, useState } from "react";
import { Html5Qrcode, Html5QrcodeSupportedFormats } from "html5-qrcode";
import { ScanBarcode } from "lucide-react";
import { toast } from "sonner";
import { pullScan } from "@/lib/inventory";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";

const FORMATS = [
  Html5QrcodeSupportedFormats.EAN_13,
  Html5QrcodeSupportedFormats.EAN_8,
  Html5QrcodeSupportedFormats.UPC_A,
  Html5QrcodeSupportedFormats.UPC_E,
  Html5QrcodeSupportedFormats.CODE_128,
  Html5QrcodeSupportedFormats.CODE_39,
];

export function usePhoneBridge(active: boolean, onCode: (code: string) => void) {
  const onCodeRef = useRef(onCode);
  onCodeRef.current = onCode;

  useEffect(() => {
    if (!active) return;
    let stop = false;
    const tick = async () => {
      if (stop) return;
      try {
        const res = await pullScan();
        if (!stop && res.barcode) onCodeRef.current(res.barcode);
      } catch {
        /* signed out / empty */
      }
    };
    const id = window.setInterval(() => void tick(), 1400);
    void tick();
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [active]);
}

export function ScanTrigger({
  onCode,
  label = "Scan barcode",
}: {
  onCode: (code: string) => void;
  label?: string;
}) {
  const [open, setOpen] = useState(false);
  usePhoneBridge(open, (code) => {
    onCode(code);
    setOpen(false);
    toast.success(`Scanned ${code}`);
  });

  return (
    <>
      <Button type="button" variant="secondary" size="sm" onClick={() => setOpen(true)}>
        <ScanBarcode className="size-4" />
        {label}
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent title="Scan barcode">
          <p className="mb-3 text-sm text-muted">
            Point this camera at the barcode, or open Scan on your phone (same account). The
            code is inserted here automatically.
          </p>
          {open && (
            <CameraBox
              onCode={(code) => {
                onCode(code);
                setOpen(false);
                toast.success(`Scanned ${code}`);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

export function CameraBox({ onCode }: { onCode: (code: string) => void }) {
  const hostId = useId().replace(/:/g, "");
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const onCodeRef = useRef(onCode);
  onCodeRef.current = onCode;

  useEffect(() => {
    const elId = `scan-${hostId}`;
    const scanner = new Html5Qrcode(elId, { verbose: false, formatsToSupport: FORMATS });
    let started = false;
    let locked = false;

    scanner
      .start(
        { facingMode: "environment" },
        { fps: 8, qrbox: { width: 240, height: 140 } },
        (text) => {
          if (locked) return;
          locked = true;
          onCodeRef.current(text.trim());
        },
        () => undefined,
      )
      .then(() => {
        started = true;
        setReady(true);
      })
      .catch((err: Error) => {
        setError(err.message || "Camera not available on this device");
      });

    return () => {
      if (started) void scanner.stop().catch(() => undefined);
    };
  }, [hostId]);

  return (
    <div className="space-y-2">
      <div
        id={`scan-${hostId}`}
        className="overflow-hidden rounded-md border border-border bg-elevated [&_video]:h-56 [&_video]:w-full [&_video]:object-cover"
      />
      {!ready && !error && <p className="text-sm text-muted">Starting camera…</p>}
      {error && (
        <p className="text-sm text-warn">
          {error}. Use Scan on your phone — the barcode will fill the desktop.
        </p>
      )}
    </div>
  );
}
