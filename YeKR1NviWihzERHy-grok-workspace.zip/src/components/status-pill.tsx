import { Badge } from "@/components/ui/badge";

export function lotTone(status: string, daysLeft: number | null) {
  if (status === "quarantined") return "warn" as const;
  if (status === "in_transit_to_factory") return "accent" as const;
  if (status === "written_off" || status === "expired") return "danger" as const;
  if (status === "expiring_soon" || (daysLeft !== null && daysLeft <= 7)) return "warn" as const;
  return "ok" as const;
}

export function LotStatus({
  status,
  daysLeft,
}: {
  status: string;
  daysLeft?: number | null;
}) {
  const label =
    status === "expiring_soon"
      ? daysLeft !== null && daysLeft !== undefined
        ? `${daysLeft}d left`
        : "Expiring"
      : status === "in_transit_to_factory"
        ? "To factory"
        : status.replaceAll("_", " ");
  return <Badge tone={lotTone(status, daysLeft ?? null)}>{label}</Badge>;
}

export function DaysLeft({ days }: { days: number | null }) {
  if (days === null) return <span className="text-subtle">No date</span>;
  if (days < 0) return <span className="font-mono text-danger tabular-nums">{days}d</span>;
  if (days <= 7) return <span className="font-mono text-warn tabular-nums">{days}d</span>;
  return <span className="font-mono text-fg tabular-nums">{days}d</span>;
}
