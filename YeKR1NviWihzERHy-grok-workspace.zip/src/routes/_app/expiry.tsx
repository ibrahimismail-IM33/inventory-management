import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { listExpiring, scrapLot } from "@/lib/inventory";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { DaysLeft, LotStatus } from "@/components/status-pill";

export const Route = createFileRoute("/_app/expiry")({ component: ExpiryBoard });

function ExpiryBoard() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["expiry"], queryFn: () => listExpiring() });
  const scrap = useMutation({
    mutationFn: (id: string) => scrapLot({ data: id }),
    onSuccess: () => {
      toast.success("Expired lot written off");
      void qc.invalidateQueries({ queryKey: ["expiry"] });
      void qc.invalidateQueries({ queryKey: ["overview"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const rows = q.data ?? [];
  const bands = [
    { key: "dead", title: "Expired", test: (d: number | null) => d !== null && d < 0 },
    { key: "week", title: "Next 7 days", test: (d: number | null) => d !== null && d >= 0 && d <= 7 },
    { key: "soon", title: "8–14 days", test: (d: number | null) => d !== null && d > 7 && d <= 14 },
    { key: "later", title: "Later", test: (d: number | null) => d !== null && d > 14 },
  ];

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl tracking-tight">Expiry countdown</h1>
        <p className="mt-1 max-w-xl text-sm text-muted">
          Days left are computed from the lot date. Expired stock is not available to sell.
          Do not ship expired lots back to the factory — scrap them.
        </p>
      </header>

      {q.isPending && <div className="h-40 animate-pulse rounded-xl bg-surface" />}

      {bands.map((band) => {
        const list = rows.filter((r) => band.test(r.daysLeft));
        return (
          <Card key={band.key} className="p-0">
            <div className="flex items-baseline justify-between border-b border-border px-5 py-4">
              <h2 className="font-display text-lg">{band.title}</h2>
              <p className="font-mono text-xs text-subtle tabular-nums">{list.length} lots</p>
            </div>
            {list.length === 0 ? (
              <p className="px-5 py-8 text-sm text-muted">Nothing in this window.</p>
            ) : (
              <ul className="divide-y divide-border">
                {list.map((row) => (
                  <li key={row.id} className="flex flex-wrap items-center gap-3 px-5 py-3">
                    <div className="min-w-0 flex-1">
                      <Link
                        to="/item/$itemId"
                        params={{ itemId: row.item_id }}
                        className="text-sm hover:underline"
                      >
                        <span className="font-mono text-xs text-muted">{row.sku}</span> {row.name}
                      </Link>
                      <p className="font-mono text-xs text-subtle">
                        {row.lot_code} · {row.expires_at}
                      </p>
                    </div>
                    <p className="font-mono text-sm tabular-nums">{row.qty}</p>
                    <DaysLeft days={row.daysLeft} />
                    <LotStatus status={row.status} daysLeft={row.daysLeft} />
                    {(row.status === "expired" || (row.daysLeft !== null && row.daysLeft < 30)) &&
                      row.status !== "written_off" && (
                        <Button
                          size="sm"
                          variant="secondary"
                          disabled={scrap.isPending}
                          onClick={() => scrap.mutate(row.id)}
                        >
                          Scrap
                        </Button>
                      )}
                  </li>
                ))}
              </ul>
            )}
          </Card>
        );
      })}
    </div>
  );
}
