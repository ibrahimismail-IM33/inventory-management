import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowUpRight } from "lucide-react";
import { getWorkspaceOverview } from "@/lib/inventory";
import { money } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { DaysLeft, LotStatus } from "@/components/status-pill";

export const Route = createFileRoute("/_app/")({ component: Overview });

function Overview() {
  const q = useQuery({ queryKey: ["overview"], queryFn: () => getWorkspaceOverview() });
  if (q.isPending) return <Pulse />;
  if (q.error) return <p className="text-danger">{(q.error as Error).message}</p>;
  const data = q.data;
  if (!data) return null;
  const { workspace, stats } = data;

  return (
    <div className="space-y-8">
      <header>
        <p className="text-[11px] font-medium tracking-[0.16em] text-subtle uppercase">
          {workspace.locationName}
        </p>
        <h1 className="mt-1 font-display text-3xl tracking-tight">{workspace.companyName}</h1>
        <p className="mt-2 max-w-xl text-sm text-muted">
          This catalog is yours alone. Search SKUs, watch lot expiry, and send confirmed factory
          defects back — never restock a broken unit.
        </p>
      </header>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat to="/catalog" label="SKUs" value={stats.skus} hint="In this company" />
        <Stat
          to="/catalog"
          label="Available"
          value={stats.available}
          hint={`${stats.onHand} on hand`}
        />
        <Stat to="/moves" label="Sold today" value={stats.soldToday} hint={`+${stats.receivedToday} received`} />
        <Stat
          to="/moves"
          label="Profit today"
          value={stats.profitToday}
          hint={`${money(stats.profitOnHand)} on hand`}
          moneyValue
          alert={stats.profitToday < 0}
        />
        <Stat
          to="/returns"
          label="Held"
          value={stats.quarantined}
          hint={`${stats.openRtv} factory RTVs open`}
        />
      </section>

      <div className="grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <div className="mb-4 flex items-end justify-between">
            <div>
              <h2 className="font-display text-lg">Expiry line</h2>
              <p className="text-sm text-muted">Soonest dated lots in this warehouse</p>
            </div>
            <Link to="/expiry" className="inline-flex items-center gap-1 text-sm text-muted hover:text-fg">
              Board <ArrowUpRight className="size-3.5" />
            </Link>
          </div>
          <ul className="divide-y divide-border">
            {data.expiring.length === 0 && (
              <li className="py-8 text-sm text-muted">No dated lots yet.</li>
            )}
            {data.expiring.map((row) => (
              <li key={row.id}>
                <Link
                  to="/item/$itemId"
                  params={{ itemId: row.item_id }}
                  className="flex items-center gap-3 py-3 hover:text-fg"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm">
                      <span className="font-mono text-xs text-muted">{row.sku}</span> {row.name}
                    </p>
                    <p className="font-mono text-xs text-subtle">{row.lot_code}</p>
                  </div>
                  <p className="hidden text-sm text-muted sm:block">{row.qty} u</p>
                  <DaysLeft days={row.daysLeft} />
                  <LotStatus status={row.status} daysLeft={row.daysLeft} />
                </Link>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="lg:col-span-2">
          <div className="flex items-end justify-between">
            <h2 className="font-display text-lg">Recent movements</h2>
            <Link to="/moves" className="inline-flex items-center gap-1 text-sm text-muted hover:text-fg">
              Ledger <ArrowUpRight className="size-3.5" />
            </Link>
          </div>
          <ul className="mt-4 divide-y divide-border">
            {data.recent.map((m) => (
              <li key={m.id}>
                <Link
                  to="/item/$itemId"
                  params={{ itemId: m.item_id }}
                  className="flex items-baseline justify-between gap-3 py-2.5 hover:text-fg"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm">
                      <span className="capitalize">{m.kind.replaceAll("_", " ")}</span>{" "}
                      <span className="font-mono text-xs text-muted">{m.sku}</span>
                    </p>
                    {m.reason && <p className="truncate text-xs text-subtle">{m.reason}</p>}
                  </div>
                  <span className="font-mono text-sm tabular-nums">
                    {m.qty > 0 ? `+${m.qty}` : m.qty}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  hint,
  to,
  alert,
  moneyValue,
}: {
  label: string;
  value: number;
  hint: string;
  to: "/catalog" | "/moves" | "/returns" | "/factory" | "/expiry";
  alert?: boolean;
  moneyValue?: boolean;
}) {
  return (
    <Link to={to} className="block">
      <Card className="p-4 transition-colors hover:border-fg/20">
        <p className="text-[11px] tracking-[0.14em] text-subtle uppercase">{label}</p>
        <p className={`mt-2 font-display text-3xl tabular-nums ${alert ? "text-danger" : "text-fg"}`}>
          {moneyValue ? money(value) : value.toLocaleString()}
        </p>
        <p className="mt-1 text-xs text-muted">{hint}</p>
      </Card>
    </Link>
  );
}

function Pulse() {
  return (
    <div className="space-y-4">
      <div className="h-10 w-64 animate-pulse rounded-sm bg-elevated" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="h-28 animate-pulse rounded-xl bg-surface" />
        ))}
      </div>
    </div>
  );
}