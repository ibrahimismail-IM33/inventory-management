import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import {
  createFactoryReturn,
  listFactoryReturns,
  listQuarantine,
  updateFactoryReturn,
} from "@/lib/inventory";
import { money } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_app/factory")({ component: FactoryPage });

function FactoryPage() {
  const qc = useQueryClient();
  const list = useQuery({ queryKey: ["factory"], queryFn: () => listFactoryReturns() });

  const advance = useMutation({
    mutationFn: (input: { id: string; status: "shipped" | "credited" | "replaced" | "rejected" }) =>
      updateFactoryReturn({ data: input }),
    onSuccess: () => {
      toast.success("Factory return updated");
      void qc.invalidateQueries({ queryKey: ["factory"] });
      void qc.invalidateQueries({ queryKey: ["overview"] });
      void qc.invalidateQueries({ queryKey: ["quarantine"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-6">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Factory returns</h1>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Quarantined factory defects ship back for credit or replacement. Expired lots and
            scrap-only SKUs stay here — they are not sent.
          </p>
        </div>
        <NewRtvButton />
      </header>

      <div className="space-y-3">
        {list.isPending && <div className="h-32 animate-pulse rounded-xl bg-surface" />}
        {list.data?.length === 0 && (
          <Card>
            <p className="text-sm text-muted">No factory RMAs yet. Hold damaged lots first.</p>
          </Card>
        )}
        {list.data?.map((rtv) => (
          <Card key={rtv.id}>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-display text-lg">{rtv.vendor_name}</p>
                <p className="font-mono text-xs text-muted">
                  {rtv.rma_number ?? "No RMA #"} · {rtv.created_at.slice(0, 10)}
                </p>
                {rtv.notes && <p className="mt-2 text-sm text-muted">{rtv.notes}</p>}
              </div>
              <div className="flex flex-col items-end gap-2">
                <RtvBadge status={rtv.status} />
                {rtv.credit_amount && (
                  <p className="text-sm text-ok">{money(rtv.credit_amount)}</p>
                )}
              </div>
            </div>
            <ul className="mt-4 divide-y divide-border border-t border-border">
              {rtv.lines.map((ln, i) => (
                <li key={`${rtv.id}-${i}`} className="flex justify-between gap-3 py-2 text-sm">
                  <span>
                    <span className="font-mono text-xs">{ln.sku}</span> {ln.name}{" "}
                    <span className="text-subtle">· {ln.lot_code}</span>
                  </span>
                  <span className="text-muted">
                    {ln.qty} · {ln.damage_code.replaceAll("_", " ")}
                  </span>
                </li>
              ))}
            </ul>
            {["draft", "submitted"].includes(rtv.status) && (
              <div className="mt-4 flex flex-wrap gap-2">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => advance.mutate({ id: rtv.id, status: "shipped" })}
                >
                  Mark shipped
                </Button>
              </div>
            )}
            {rtv.status === "shipped" && (
              <div className="mt-4 flex flex-wrap gap-2">
                <Button size="sm" onClick={() => advance.mutate({ id: rtv.id, status: "credited" })}>
                  Credit received
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => advance.mutate({ id: rtv.id, status: "replaced" })}
                >
                  Replacement received
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => advance.mutate({ id: rtv.id, status: "rejected" })}
                >
                  Factory rejected
                </Button>
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}

function RtvBadge({ status }: { status: string }) {
  const tone =
    status === "credited" || status === "replaced"
      ? "ok"
      : status === "rejected"
        ? "danger"
        : status === "shipped"
          ? "accent"
          : "warn";
  return <Badge tone={tone}>{status}</Badge>;
}

function NewRtvButton() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [vendor, setVendor] = useState("");
  const [rma, setRma] = useState("");
  const [notes, setNotes] = useState("");
  const [picked, setPicked] = useState<Record<string, string>>({});

  const hold = useQuery({
    queryKey: ["quarantine"],
    queryFn: () => listQuarantine(),
    enabled: open,
  });

  const mut = useMutation({
    mutationFn: () =>
      createFactoryReturn({
        data: {
          vendorName: vendor,
          rmaNumber: rma,
          notes,
          lines: Object.entries(picked).map(([lotId, damageCode]) => ({ lotId, damageCode })),
        },
      }),
    onSuccess: () => {
      toast.success("Factory return submitted");
      void qc.invalidateQueries({ queryKey: ["factory"] });
      void qc.invalidateQueries({ queryKey: ["quarantine"] });
      void qc.invalidateQueries({ queryKey: ["overview"] });
      setOpen(false);
      setPicked({});
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const eligible = hold.data?.filter((row) => row.return_to_factory) ?? [];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>New factory RTV</Button>
      </DialogTrigger>
      <DialogContent title="Send to factory">
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            mut.mutate();
          }}
        >
          <div className="space-y-1.5">
            <Label htmlFor="vendor">Factory / vendor</Label>
            <Input id="vendor" value={vendor} onChange={(e) => setVendor(e.target.value)} required />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="rma">RMA number</Label>
            <Input id="rma" value={rma} onChange={(e) => setRma(e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1.5">
            <Label>Quarantined lots</Label>
            <ul className="max-h-48 space-y-2 overflow-auto rounded-sm border border-border p-2">
              {hold.isPending && <li className="p-2 text-sm text-muted">Loading hold…</li>}
              {eligible.length === 0 && !hold.isPending && (
                <li className="p-2 text-sm text-muted">
                  Nothing eligible. Hold a factory-return SKU first. Dated lots under 30 days are blocked.
                </li>
              )}
              {eligible.map((row) => {
                const on = row.id in picked;
                return (
                  <li key={row.id} className="flex items-start gap-2 rounded-sm p-2 hover:bg-elevated">
                    <input
                      type="checkbox"
                      className="mt-1"
                      checked={on}
                      onChange={(e) => {
                        setPicked((prev) => {
                          const next = { ...prev };
                          if (e.target.checked) next[row.id] = "INBOUND_DAMAGED";
                          else delete next[row.id];
                          return next;
                        });
                      }}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm">
                        <span className="font-mono text-xs">{row.sku}</span> {row.name}
                      </p>
                      <p className="font-mono text-xs text-subtle">
                        {row.lot_code} · {row.qty} u
                        {row.expires_at ? ` · exp ${row.expires_at}` : ""}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="notes">Notes</Label>
            <Input id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
          <Button type="submit" className="w-full" disabled={mut.isPending || Object.keys(picked).length === 0}>
            Submit RTV
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
