import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Search, Upload } from "lucide-react";
import { createItem, importItems, searchItems } from "@/lib/inventory";
import { money } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScanTrigger, usePhoneBridge } from "@/components/scanner";

export const Route = createFileRoute("/_app/catalog")({ component: Catalog });

function Catalog() {
  const [q, setQ] = useState("");
  const [debounced, setDebounced] = useState("");
  const [category, setCategory] = useState("");
  const [page, setPage] = useState(0);

  useEffect(() => {
    const t = window.setTimeout(() => {
      setDebounced(q);
      setPage(0);
    }, 200);
    return () => window.clearTimeout(t);
  }, [q]);

  const list = useQuery({
    queryKey: ["items", debounced, category, page],
    queryFn: () => searchItems({ data: { q: debounced, category, page } }),
  });

  const data = list.data;
  const pages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <div className="space-y-6">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Catalog</h1>
          <p className="mt-1 text-sm text-muted">
            Search by SKU, name, or barcode. Built for large catalogs — this page never loads everything.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <ImportCsvButton />
          <AddSkuButton />
        </div>
      </header>

      <div className="flex flex-col gap-3 sm:flex-row">
        <label className="relative min-w-0 flex-1">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="SKU, name, or barcode"
            className="pl-10"
          />
        </label>
        <select
          value={category}
          onChange={(e) => {
            setCategory(e.target.value);
            setPage(0);
          }}
          className="h-11 rounded-sm border border-border bg-elevated px-3 text-sm text-fg"
        >
          <option value="">All categories</option>
          {data?.categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      <div className="overflow-x-auto rounded-xl border border-border bg-surface">
        <table className="w-full min-w-[860px] text-left text-sm">
          <thead className="text-[11px] tracking-[0.12em] text-subtle uppercase">
            <tr className="border-b border-border">
              <th className="px-4 py-3 font-medium">SKU</th>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium text-right">Available</th>
              <th className="px-4 py-3 font-medium text-right">Held</th>
              <th className="px-4 py-3 font-medium text-right">Cost</th>
              <th className="px-4 py-3 font-medium text-right">Sell</th>
              <th className="px-4 py-3 font-medium">Expiry</th>
            </tr>
          </thead>
          <tbody>
            {list.isPending && (
              <tr>
                <td colSpan={8} className="px-4 py-10 text-center text-muted">
                  Searching…
                </td>
              </tr>
            )}
            {data?.items.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-10 text-center text-muted">
                  No SKUs match that search.
                </td>
              </tr>
            )}
            {data?.items.map((item) => (
              <tr key={item.id} className="border-b border-border last:border-0 hover:bg-elevated/50">
                <td className="px-4 py-3">
                  <Link
                    to="/item/$itemId"
                    params={{ itemId: item.id }}
                    className="font-mono text-xs hover:underline"
                  >
                    {item.sku}
                  </Link>
                </td>
                <td className="px-4 py-3">
                  <Link to="/item/$itemId" params={{ itemId: item.id }} className="hover:underline">
                    {item.name}
                  </Link>
                </td>
                <td className="px-4 py-3 text-muted">{item.category}</td>
                <td className="px-4 py-3 text-right font-mono tabular-nums">{item.available}</td>
                <td className="px-4 py-3 text-right font-mono tabular-nums text-warn">
                  {item.quarantined || "—"}
                </td>
                <td className="px-4 py-3 text-right font-mono tabular-nums">{money(item.cost)}</td>
                <td className="px-4 py-3 text-right font-mono tabular-nums">{money(item.sellPrice)}</td>
                <td className="px-4 py-3 font-mono text-xs tabular-nums">
                  {item.expiresAt ? (
                    <span className={item.daysLeft !== null && item.daysLeft <= 7 ? "text-warn" : undefined}>
                      {item.expiresAt}
                      {item.daysLeft !== null && (
                        <span className="ml-1 text-subtle">
                          {item.daysLeft < 0 ? "expired" : `${item.daysLeft}d`}
                        </span>
                      )}
                    </span>
                  ) : (
                    <span className="text-subtle">—</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {data && (
        <div className="flex items-center justify-between text-sm text-muted">
          <p>
            {data.total.toLocaleString()} SKUs
            {debounced ? ` matching “${debounced}”` : ""}
          </p>
          <div className="flex gap-2">
            <Button
              variant="secondary"
              size="sm"
              disabled={page <= 0}
              onClick={() => setPage((p) => Math.max(0, p - 1))}
            >
              Previous
            </Button>
            <span className="grid h-9 place-items-center px-2 tabular-nums">
              {page + 1} / {pages}
            </span>
            <Button
              variant="secondary"
              size="sm"
              disabled={page + 1 >= pages}
              onClick={() => setPage((p) => p + 1)}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function AddSkuButton() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [sku, setSku] = useState("");
  const [name, setName] = useState("");
  const [category, setCategory] = useState("General");
  const [barcode, setBarcode] = useState("");
  const [cost, setCost] = useState("");
  const [sellPrice, setSellPrice] = useState("");
  const [openingQty, setOpeningQty] = useState("0");
  const [lotCode, setLotCode] = useState("OPEN");
  const [hasExpiry, setHasExpiry] = useState(false);
  const [expiresAt, setExpiresAt] = useState("");
  const [returnToFactory, setReturnToFactory] = useState(true);

  usePhoneBridge(open, (code) => setBarcode(code));

  const mut = useMutation({
    mutationFn: () =>
      createItem({
        data: {
          sku,
          name,
          category,
          barcode,
          cost: Number(cost),
          sellPrice: Number(sellPrice),
          hasExpiry,
          returnToFactory,
          openingQty: Number(openingQty),
          lotCode,
          expiresAt: hasExpiry ? expiresAt : null,
        },
      }),
    onSuccess: () => {
      toast.success("SKU added to your catalog");
      void qc.invalidateQueries({ queryKey: ["items"] });
      void qc.invalidateQueries({ queryKey: ["overview"] });
      setOpen(false);
      setSku("");
      setName("");
      setBarcode("");
      setCost("");
      setSellPrice("");
      setOpeningQty("0");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="size-4" />
          Add SKU
        </Button>
      </DialogTrigger>
      <DialogContent title="New SKU">
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            mut.mutate();
          }}
        >
          <div className="space-y-1.5">
            <Label htmlFor="sku">SKU</Label>
            <Input id="sku" value={sku} onChange={(e) => setSku(e.target.value)} required className="font-mono" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="iname">Name</Label>
            <Input id="iname" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <Label htmlFor="bc">Barcode</Label>
              <ScanTrigger onCode={setBarcode} label="Scan" />
            </div>
            <Input
              id="bc"
              value={barcode}
              onChange={(e) => setBarcode(e.target.value)}
              className="font-mono"
              placeholder="Scan or type"
            />
            {open && (
              <p className="text-xs text-subtle">Phone Scan on the same account fills this field.</p>
            )}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="cost">Cost</Label>
              <Input id="cost" type="number" min={0} step="0.01" value={cost} onChange={(e) => setCost(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sell">Sell price</Label>
              <Input
                id="sell"
                type="number"
                min={0}
                step="0.01"
                value={sellPrice}
                onChange={(e) => setSellPrice(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cat">Category</Label>
            <Input id="cat" value={category} onChange={(e) => setCategory(e.target.value)} />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={hasExpiry} onChange={(e) => setHasExpiry(e.target.checked)} />
            First lot has an expiry date
          </label>
          {hasExpiry && (
            <div className="space-y-1.5">
              <Label htmlFor="exp">Expiry date</Label>
              <Input id="exp" type="date" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} required />
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="oqty">Opening qty</Label>
              <Input id="oqty" type="number" min={0} value={openingQty} onChange={(e) => setOpeningQty(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="olot">Lot code</Label>
              <Input id="olot" value={lotCode} onChange={(e) => setLotCode(e.target.value)} className="font-mono" />
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={returnToFactory}
              onChange={(e) => setReturnToFactory(e.target.checked)}
            />
            Damaged units may return to factory
          </label>
          <Button type="submit" className="w-full" disabled={mut.isPending}>
            Save SKU
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

const CSV_TEMPLATE = `sku,name,category,barcode,unit,cost,sell_price,has_expiry,return_to_factory,opening_qty,lot_code,expires_at
YOG-500,Greek yogurt 500g,Dairy,400000000099,ea,1.10,2.40,true,true,24,L1,2026-09-01
HX-M10,Hex bolt M10,Fasteners,100000000099,ea,0.20,0.45,false,false,100,BULK,
`;

function ImportCsvButton() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [rows, setRows] = useState<ReturnType<typeof mapCsvRows>>([]);
  const [parseError, setParseError] = useState<string | null>(null);
  const [fileName, setFileName] = useState("");

  const mut = useMutation({
    mutationFn: () => importItems({ data: { rows } }),
    onSuccess: (res) => {
      toast.success(`Imported ${res.created} SKUs${res.skipped ? ` · ${res.skipped} skipped` : ""}`);
      if (res.errors.length) toast.error(res.errors.slice(0, 3).join(" · "));
      void qc.invalidateQueries({ queryKey: ["items"] });
      void qc.invalidateQueries({ queryKey: ["overview"] });
      setOpen(false);
      setRows([]);
      setFileName("");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) {
          setRows([]);
          setParseError(null);
          setFileName("");
        }
      }}
    >
      <DialogTrigger asChild>
        <Button variant="secondary">
          <Upload className="size-4" />
          Import CSV
        </Button>
      </DialogTrigger>
      <DialogContent title="Import catalog CSV">
        <p className="mb-3 text-sm text-muted">
          One SKU per row. Max 500. Duplicate SKU or barcode is skipped. Dated
          opening stock needs <span className="font-mono text-xs">expires_at</span>.
        </p>
        <div className="mb-3 flex flex-wrap gap-2">
          <Button type="button" variant="secondary" size="sm" onClick={downloadTemplate}>
            Download template
          </Button>
          <Label className="inline-flex h-9 cursor-pointer items-center rounded-sm border border-border bg-elevated px-3 text-xs font-medium">
            Choose file
            <input
              type="file"
              accept=".csv,text/csv"
              className="sr-only"
              onChange={(e) => {
                const file = e.target.files?.[0];
                e.target.value = "";
                if (!file) return;
                setFileName(file.name);
                void file.text().then((text) => {
                  try {
                    const parsed = mapCsvRows(parseCsv(text));
                    setRows(parsed);
                    setParseError(parsed.length ? null : "No SKU rows found");
                  } catch (err) {
                    setRows([]);
                    setParseError(err instanceof Error ? err.message : "Could not read CSV");
                  }
                });
              }}
            />
          </Label>
        </div>
        {fileName && <p className="mb-2 text-xs text-subtle">{fileName}</p>}
        {parseError && <p className="mb-2 text-sm text-warn">{parseError}</p>}
        {rows.length > 0 && (
          <div className="mb-3 overflow-x-auto rounded-sm border border-border">
            <table className="w-full min-w-[480px] text-left text-xs">
              <thead className="text-subtle">
                <tr className="border-b border-border">
                  <th className="px-2 py-1.5 font-medium">SKU</th>
                  <th className="px-2 py-1.5 font-medium">Name</th>
                  <th className="px-2 py-1.5 font-medium text-right">Cost</th>
                  <th className="px-2 py-1.5 font-medium text-right">Sell</th>
                  <th className="px-2 py-1.5 font-medium">Expiry</th>
                </tr>
              </thead>
              <tbody>
                {rows.slice(0, 6).map((row) => (
                  <tr key={row.sku} className="border-b border-border last:border-0">
                    <td className="px-2 py-1.5 font-mono">{row.sku}</td>
                    <td className="px-2 py-1.5">{row.name}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{money(row.cost)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{money(row.sellPrice)}</td>
                    <td className="px-2 py-1.5 font-mono">{row.expiresAt || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {rows.length > 6 && (
              <p className="px-2 py-1.5 text-xs text-subtle">{rows.length - 6} more rows</p>
            )}
          </div>
        )}
        <Button
          className="w-full"
          disabled={mut.isPending || rows.length === 0}
          onClick={() => mut.mutate()}
        >
          Import {rows.length || ""} SKUs
        </Button>
      </DialogContent>
    </Dialog>
  );
}

function downloadTemplate() {
  const blob = new Blob([CSV_TEMPLATE], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "lotline-catalog-template.csv";
  a.click();
  URL.revokeObjectURL(url);
}

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  const src = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else {
          quoted = false;
        }
      } else {
        cell += ch;
      }
    } else if (ch === '"') {
      quoted = true;
    } else if (ch === ",") {
      row.push(cell.trim());
      cell = "";
    } else if (ch === "\n") {
      row.push(cell.trim());
      if (row.some((c) => c)) rows.push(row);
      row = [];
      cell = "";
    } else if (ch !== "\r") {
      cell += ch;
    }
  }
  row.push(cell.trim());
  if (row.some((c) => c)) rows.push(row);
  return rows;
}

function truthy(value: string) {
  return ["1", "true", "yes", "y"].includes(value.trim().toLowerCase());
}

function mapCsvRows(table: string[][]) {
  if (table.length < 2) return [];
  const headers = table[0].map((h) => h.trim().toLowerCase().replace(/\s+/g, "_"));
  const idx = (names: string[]) => headers.findIndex((h) => names.includes(h));
  const skuI = idx(["sku"]);
  const nameI = idx(["name"]);
  if (skuI < 0 || nameI < 0) throw new Error("CSV needs sku and name columns");
  const catI = idx(["category"]);
  const barI = idx(["barcode"]);
  const unitI = idx(["unit"]);
  const costI = idx(["cost"]);
  const sellI = idx(["sell_price", "sell", "sellprice", "price"]);
  const expFlagI = idx(["has_expiry", "expiry", "dated"]);
  const rtvI = idx(["return_to_factory", "factory"]);
  const qtyI = idx(["opening_qty", "qty", "quantity"]);
  const lotI = idx(["lot_code", "lot"]);
  const dateI = idx(["expires_at", "expiry_date", "expired_date", "expire_date"]);

  return table.slice(1).flatMap((cells) => {
    const sku = cells[skuI] ?? "";
    const name = cells[nameI] ?? "";
    if (!sku && !name) return [];
    const expiresAt = dateI >= 0 ? cells[dateI] || null : null;
    return [
      {
        sku,
        name,
        category: catI >= 0 ? cells[catI] : "General",
        barcode: barI >= 0 ? cells[barI] : "",
        unit: unitI >= 0 ? cells[unitI] : "ea",
        cost: costI >= 0 ? Number(cells[costI]) || 0 : 0,
        sellPrice: sellI >= 0 ? Number(cells[sellI]) || 0 : 0,
        hasExpiry: expFlagI >= 0 ? truthy(cells[expFlagI] ?? "") : Boolean(expiresAt),
        returnToFactory: rtvI >= 0 ? truthy(cells[rtvI] ?? "true") : true,
        openingQty: qtyI >= 0 ? Number(cells[qtyI]) || 0 : 0,
        lotCode: lotI >= 0 ? cells[lotI] : "OPEN",
        expiresAt,
      },
    ];
  });
}
