import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { createBuyerReturn, getItemDetail, listBuyerReturns, searchItems } from "@/lib/inventory";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_app/returns")({ component: ReturnsPage });

function ReturnsPage() {
  const list = useQuery({ queryKey: ["buyer-returns"], queryFn: () => listBuyerReturns() });

  return (
    <div className="space-y-6">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Buyer returns</h1>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Buyer received a broken unit. Make them whole, then hold the piece in quarantine.
            It does not go back on the shelf.
          </p>
        </div>
        <NewReturnButton />
      </header>

      <Card className="p-0">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="text-[11px] tracking-[0.12em] text-subtle uppercase">
            <tr className="border-b border-border">
              <th className="px-5 py-3 font-medium">When</th>
              <th className="px-5 py-3 font-medium">SKU</th>
              <th className="px-5 py-3 font-medium">Buyer</th>
              <th className="px-5 py-3 font-medium">Code</th>
              <th className="px-5 py-3 font-medium text-right">Qty</th>
              <th className="px-5 py-3 font-medium">Outcome</th>
            </tr>
          </thead>
          <tbody>
            {list.isPending && (
              <tr>
                <td colSpan={6} className="px-5 py-10 text-muted">
                  Loading…
                </td>
              </tr>
            )}
            {list.data?.length === 0 && (
              <tr>
                <td colSpan={6} className="px-5 py-10 text-muted">
                  No buyer returns yet.
                </td>
              </tr>
            )}
            {list.data?.map((row) => (
              <tr key={row.id} className="border-b border-border last:border-0">
                <td className="px-5 py-3 text-muted">
                  {row.created_at.slice(0, 16).replace("T", " ")}
                </td>
                <td className="px-5 py-3">
                  <p className="font-mono text-xs">{row.sku}</p>
                  <p className="text-muted">{row.name}</p>
                </td>
                <td className="px-5 py-3">
                  <p>{row.buyer_name ?? "—"}</p>
                  <p className="font-mono text-xs text-subtle">{row.order_ref ?? ""}</p>
                </td>
                <td className="px-5 py-3">
                  <Badge tone="warn">{row.damage_code.replaceAll("_", " ")}</Badge>
                </td>
                <td className="px-5 py-3 text-right font-mono tabular-nums">{row.qty}</td>
                <td className="px-5 py-3">
                  <Badge>
                    {row.decision} · {row.outcome}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

function NewReturnButton() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [itemId, setItemId] = useState("");
  const [lotId, setLotId] = useState("");
  const [qty, setQty] = useState("1");
  const [damageCode, setDamageCode] = useState("DOA");
  const [buyerName, setBuyerName] = useState("");
  const [orderRef, setOrderRef] = useState("");
  const [decision, setDecision] = useState("refund");

  const search = useQuery({
    queryKey: ["items", q, "", 0],
    queryFn: () => searchItems({ data: { q, page: 0 } }),
    enabled: open && q.length >= 1,
  });
  const detail = useQuery({
    queryKey: ["item", itemId],
    queryFn: () => getItemDetail({ data: itemId }),
    enabled: Boolean(itemId),
  });

  const picked = useMemo(
    () => search.data?.items.find((i) => i.id === itemId),
    [search.data, itemId],
  );

  const mut = useMutation({
    mutationFn: () =>
      createBuyerReturn({
        data: {
          itemId,
          lotId,
          qty: Number(qty),
          damageCode,
          buyerName,
          orderRef,
          decision,
        },
      }),
    onSuccess: () => {
      toast.success("Buyer return held in quarantine");
      void qc.invalidateQueries({ queryKey: ["buyer-returns"] });
      void qc.invalidateQueries({ queryKey: ["overview"] });
      setOpen(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Log broken return</Button>
      </DialogTrigger>
      <DialogContent title="Buyer received it broken">
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            mut.mutate();
          }}
        >
          <div className="space-y-1.5">
            <Label htmlFor="find">Find SKU</Label>
            <Input
              id="find"
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                setItemId("");
                setLotId("");
              }}
              placeholder="Type a SKU or name"
            />
            {search.data && !itemId && (
              <ul className="max-h-32 overflow-auto rounded-sm border border-border">
                {search.data.items.slice(0, 6).map((item) => (
                  <li key={item.id}>
                    <button
                      type="button"
                      className="w-full px-3 py-2 text-left text-sm hover:bg-elevated"
                      onClick={() => {
                        setItemId(item.id);
                        setQ(`${item.sku} · ${item.name}`);
                      }}
                    >
                      <span className="font-mono text-xs">{item.sku}</span> {item.name}
                    </button>
                  </li>
                ))}
              </ul>
            )}
            {picked && <p className="text-xs text-ok">Selected {picked.sku}</p>}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="lot">Original lot</Label>
            <select
              id="lot"
              required
              value={lotId}
              onChange={(e) => setLotId(e.target.value)}
              className="h-11 w-full rounded-sm border border-border bg-elevated px-3 text-sm"
            >
              <option value="">Select lot</option>
              {detail.data?.lots.map((lot) => (
                <option key={lot.id} value={lot.id}>
                  {lot.lot_code}
                  {lot.expires_at ? ` · exp ${lot.expires_at}` : ""}
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="qty">Qty</Label>
              <Input id="qty" type="number" min={1} value={qty} onChange={(e) => setQty(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="dmg">Damage</Label>
              <select
                id="dmg"
                value={damageCode}
                onChange={(e) => setDamageCode(e.target.value)}
                className="h-11 w-full rounded-sm border border-border bg-elevated px-3 text-sm"
              >
                <option value="DOA">Dead on arrival</option>
                <option value="TRANSIT_BROKEN">Broken in transit</option>
                <option value="MISSING_PARTS">Missing parts</option>
                <option value="WRONG_ITEM">Wrong item</option>
              </select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="buyer">Buyer</Label>
            <Input id="buyer" value={buyerName} onChange={(e) => setBuyerName(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="so">Order / SO</Label>
            <Input id="so" value={orderRef} onChange={(e) => setOrderRef(e.target.value)} className="font-mono" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="dec">Make buyer whole</Label>
            <select
              id="dec"
              value={decision}
              onChange={(e) => setDecision(e.target.value)}
              className="h-11 w-full rounded-sm border border-border bg-elevated px-3 text-sm"
            >
              <option value="refund">Refund</option>
              <option value="replace">Replace from good stock</option>
            </select>
          </div>
          <Button type="submit" className="w-full" disabled={mut.isPending || !itemId || !lotId}>
            Hold in quarantine
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
