import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { lookupByBarcode, postScan } from "@/lib/inventory";
import { CameraBox } from "@/components/scanner";
import { UnknownBarcode } from "@/components/unknown-barcode";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/_app/scan")({ component: ScanPage });

function ScanPage() {
  const [last, setLast] = useState<string | null>(null);
  const [found, setFound] = useState<{ id: string; sku: string; name: string; available: number } | null>(null);
  const [unknown, setUnknown] = useState<string | null>(null);

  const send = useMutation({
    mutationFn: async (code: string) => {
      await postScan({ data: code });
      return lookupByBarcode({ data: code });
    },
    onSuccess: (res, code) => {
      setLast(code);
      if (res.item) {
        setFound({
          id: res.item.id,
          sku: res.item.sku,
          name: res.item.name,
          available: res.item.available,
        });
        setUnknown(null);
        toast.success(`Sent ${code} to desktop`);
      } else {
        setFound(null);
        setUnknown(code);
      }
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="mx-auto max-w-md space-y-5">
      <header>
        <h1 className="font-display text-3xl tracking-tight">Scan</h1>
        <p className="mt-1 text-sm text-muted">
          Phone camera. The barcode is inserted on the signed-in desktop automatically
          (Add SKU, stock in, or sale). Retail barcodes do not carry expiry — type the date
          on the desktop when you create the first lot.
        </p>
      </header>

      <Card>
        <CameraBox onCode={(code) => send.mutate(code)} />
      </Card>

      {last && (
        <Card>
          <p className="text-[11px] tracking-[0.14em] text-subtle uppercase">Last scan</p>
          <p className="mt-1 font-mono text-lg">{last}</p>
          {found ? (
            <div className="mt-3 space-y-2">
              <p className="text-sm">
                {found.sku} · {found.name} · {found.available} available
              </p>
              <p className="text-xs text-ok">Sent to desktop</p>
              <div className="flex flex-wrap gap-2">
                <Button asChild size="sm" variant="secondary">
                  <Link to="/moves">Stock in / sale</Link>
                </Button>
                <Button asChild size="sm" variant="ghost">
                  <Link to="/item/$itemId" params={{ itemId: found.id }}>
                    Open SKU
                  </Link>
                </Button>
              </div>
            </div>
          ) : (
            <p className="mt-2 text-sm text-warn">Not in this catalog — create it or ignore.</p>
          )}
        </Card>
      )}

      <UnknownBarcode barcode={unknown} onClose={() => setUnknown(null)} />
    </div>
  );
}
