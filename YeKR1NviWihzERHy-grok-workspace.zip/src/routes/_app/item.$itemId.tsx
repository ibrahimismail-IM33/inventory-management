import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { getItemDetail, quarantineStock, receiveStock, scrapLot, sellItem } from "@/lib/inventory";
import { money } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DaysLeft, LotStatus } from "@/components/status-pill";

export const Route = createFileRoute("/_app/item/$itemId")({ component: ItemPage });

function ItemPage() {
  const { itemId } = Route.useParams();
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["item", itemId],
    queryFn: () => getItemDetail({ data: itemId }),
  });

  if (q.isPending) return <div className="h-40 animate-pulse rounded-xl bg-surface" />;
  if (q.error) return <p className="text-danger">{(q.error as Error).message}</p>;
  const data = q.data;
  if (!data) return null;
  const { item } = data;
  const refresh = () => {
    void qc.invalidateQueries({ queryKey: ["item", itemId] });
    void qc.invalidateQueries({ queryKey: ["overview"] });
    void qc.invalidateQueries({ queryKey: ["inout"] });
  };

  return (
    <div className="space-y-6">
      <p className="text-sm">
        <Link to="/catalog" className="text-muted hover:text-fg">
          Catalog
        </Link>
        <span className="text-subtle"> / </span>
        <span className="font-mono text-xs">{item.sku}</span>
      </p>
      <header className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h1 className="font-display text-3xl tracking-tight">{item.name}</h1>
          <p className="mt-1 text-sm text-muted">
            {item.category} · {item.unit} · cost {money(item.cost)} · sell {money(item.sellPrice)}
            {item.barcode ? ` · ${item.barcode}` : ""} · {data.locationName}
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            {item.hasExpiry && <Badge>Dated lots</Badge>}
            {item.returnToFactory ? (
              <Badge tone="accent">Factory RTV allowed</Badge>
            ) : (
              <Badge>Scrap only</Badge>
            )}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <SellButton itemId={item.id} available={item.available} onDone={refresh} />
          <ReceiveButton itemId={item.id} hasExpiry={item.hasExpiry} onDone={refresh} />
        </div>
      </header>

      <section className="grid grid-cols-3 gap-3">
        <Card className="p-4">
          <p className="text-[11px] tracking-[0.14em] text-subtle uppercase">Available</p>
          <p className="mt-1 font-display text-2xl tabular-nums">{item.available}</p>
        </Card>
        <Card className="p-4">
          <p className="text-[11px] tracking-[0.14em] text-subtle uppercase">Held</p>
          <p className="mt-1 font-display text-2xl tabular-nums text-warn">{item.quarantined}</p>
        </Card>
        <Card className="p-4">
          <p className="text-[11px] tracking-[0.14em] text-subtle uppercase">On hand</p>
          <p className="mt-1 font-display text-2xl tabular-nums">{item.onHand}</p>
        </Card>
      </section>

      <Card className="p-0">
        <div className="border-b border-border px-5 py-4">
          <h2 className="font-display text-lg">Lots</h2>
          <p className="text-sm text-muted">Expiry and hold status live on the lot, not the SKU.</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="text-[11px] tracking-[0.12em] text-subtle uppercase">
              <tr className="border-b border-border">
                <th className="px-5 py-3 font-medium">Lot</th>
                <th className="px-5 py-3 font-medium">Expires</th>
                <th className="px-5 py-3 font-medium">Countdown</th>
                <th className="px-5 py-3 font-medium text-right">Qty</th>
                <th className="px-5 py-3 font-medium">Status</th>
                <th className="px-5 py-3 font-medium" />
              </tr>
            </thead>
            <tbody>
              {data.lots.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-muted">
                    No stock received yet.
                  </td>
                </tr>
              )}
              {data.lots.map((lot) => (
                <tr key={lot.id} className="border-b border-border last:border-0">
                  <td className="px-5 py-3 font-mono text-xs">{lot.lot_code}</td>
                  <td className="px-5 py-3 text-muted">{lot.expires_at ?? "—"}</td>
                  <td className="px-5 py-3">
                    <DaysLeft days={lot.daysLeft} />
                  </td>
                  <td className="px-5 py-3 text-right font-mono tabular-nums">{lot.qty}</td>
                  <td className="px-5 py-3">
                    <LotStatus status={lot.status} daysLeft={lot.daysLeft} />
                  </td>
                  <td className="px-5 py-3 text-right">
                    {lot.qty > 0 && lot.status !== "written_off" && lot.status !== "in_transit_to_factory" && (
                      <span className="inline-flex gap-2">
                        {lot.status !== "quarantined" && (
                          <HoldButton lotId={lot.id} max={lot.qty} onDone={refresh} />
                        )}
                        <ScrapButton lotId={lot.id} onDone={refresh} />
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card>
        <h2 className="font-display text-lg">Movement log</h2>
        <ul className="mt-3 divide-y divide-border">
          {data.movements.map((m) => (
            <li key={m.id} className="flex items-baseline justify-between gap-3 py-2.5 text-sm">
              <span>
                <span className="capitalize">{m.kind.replaceAll("_", " ")}</span>{" "}
                <span className="font-mono text-xs text-muted">{m.lot_code}</span>
                {m.reason ? <span className="text-subtle"> — {m.reason}</span> : null}
              </span>
              <span className="font-mono tabular-nums">{m.qty > 0 ? `+${m.qty}` : m.qty}</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

function SellButton({
  itemId,
  available,
  onDone,
}: {
  itemId: string;
  available: number;
  onDone: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [qty, setQty] = useState("1");
  const [buyer, setBuyer] = useState("");
  const [orderRef, setOrderRef] = useState("");
  const mut = useMutation({
    mutationFn: () =>
      sellItem({
        data: { itemId, qty: Number(qty), buyerName: buyer, orderRef },
      }),
    onSuccess: (res) => {
      toast.success(`Sold ${qty} · ${res.allocations.map((a) => a.lotCode).join(", ")}`);
      setOpen(false);
      onDone();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="secondary" disabled={available <= 0}>
          Record sale
        </Button>
      </DialogTrigger>
      <DialogContent title="Buyer purchase">
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            mut.mutate();
          }}
        >
          <p className="text-sm text-muted">
            {available} available. The system picks lots automatically (oldest expiry first).
          </p>
          <div className="space-y-1.5">
            <Label htmlFor="sqty">Quantity</Label>
            <Input
              id="sqty"
              type="number"
              min={1}
              max={available}
              value={qty}
              onChange={(e) => setQty(e.target.value)}
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="sbuyer">Buyer</Label>
            <Input id="sbuyer" value={buyer} onChange={(e) => setBuyer(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="sso">Order / SO</Label>
            <Input id="sso" value={orderRef} onChange={(e) => setOrderRef(e.target.value)} className="font-mono" />
          </div>
          <Button type="submit" className="w-full" disabled={mut.isPending}>
            Minus stock
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function ReceiveButton({
  itemId,
  hasExpiry,
  onDone,
}: {
  itemId: string;
  hasExpiry: boolean;
  onDone: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [lotCode, setLotCode] = useState("");
  const [qty, setQty] = useState("10");
  const [expiresAt, setExpiresAt] = useState("");
  const mut = useMutation({
    mutationFn: () =>
      receiveStock({
        data: {
          itemId,
          lotCode,
          qty: Number(qty),
          expiresAt: hasExpiry ? expiresAt : null,
        },
      }),
    onSuccess: () => {
      toast.success("Received into warehouse");
      setOpen(false);
      onDone();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Receive stock</Button>
      </DialogTrigger>
      <DialogContent title="New stock in">
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            mut.mutate();
          }}
        >
          <div className="space-y-1.5">
            <Label htmlFor="lot">Lot code</Label>
            <Input
              id="lot"
              value={lotCode}
              onChange={(e) => setLotCode(e.target.value)}
              placeholder="BULK"
              className="font-mono"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="qty">Quantity</Label>
            <Input id="qty" type="number" min={1} value={qty} onChange={(e) => setQty(e.target.value)} required />
          </div>
          {hasExpiry && (
            <div className="space-y-1.5">
              <Label htmlFor="exp">Expires</Label>
              <Input id="exp" type="date" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} required />
            </div>
          )}
          <Button type="submit" className="w-full" disabled={mut.isPending}>
            Plus stock
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function HoldButton({ lotId, max, onDone }: { lotId: string; max: number; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [qty, setQty] = useState(String(max));
  const [code, setCode] = useState("INBOUND_DAMAGED");
  const mut = useMutation({
    mutationFn: () =>
      quarantineStock({ data: { lotId, qty: Number(qty), damageCode: code } }),
    onSuccess: () => {
      toast.success("Moved to quarantine");
      setOpen(false);
      onDone();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="secondary" size="sm">
          Hold
        </Button>
      </DialogTrigger>
      <DialogContent title="Hold damaged stock">
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            mut.mutate();
          }}
        >
          <p className="text-sm text-muted">
            Pulls units off the shelf. They cannot be sold until you scrap them or send them to the factory.
          </p>
          <div className="space-y-1.5">
            <Label htmlFor="hqty">Quantity (max {max})</Label>
            <Input id="hqty" type="number" min={1} max={max} value={qty} onChange={(e) => setQty(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="code">Damage code</Label>
            <select
              id="code"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="h-11 w-full rounded-sm border border-border bg-elevated px-3 text-sm"
            >
              <option value="INBOUND_DAMAGED">Inbound damaged</option>
              <option value="IN_STORAGE_DAMAGED">Damaged in storage</option>
              <option value="DOA">Dead on arrival (from buyer)</option>
              <option value="MISSING_PARTS">Missing parts</option>
            </select>
          </div>
          <Button type="submit" className="w-full" disabled={mut.isPending}>
            Quarantine
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function ScrapButton({ lotId, onDone }: { lotId: string; onDone: () => void }) {
  const mut = useMutation({
    mutationFn: () => scrapLot({ data: lotId }),
    onSuccess: () => {
      toast.success("Lot written off");
      onDone();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  return (
    <Button variant="ghost" size="sm" onClick={() => mut.mutate()} disabled={mut.isPending}>
      Scrap
    </Button>
  );
}
