import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { getItemDetail, listInOutMoves, lookupByBarcode, receiveStock, searchItems, sellItem } from "@/lib/inventory";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScanTrigger } from "@/components/scanner";
import { UnknownBarcode } from "@/components/unknown-barcode";

export const Route = createFileRoute("/_app/moves")({ component: MovesPage });

function MovesPage() {
  const ledger = useQuery({ queryKey: ["inout"], queryFn: () => listInOutMoves() });
  const [unknown, setUnknown] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl tracking-tight">Stock in / out</h1>
        <p className="mt-1 max-w-xl text-sm text-muted">
          A sale automatically minus available lots (oldest expiry first). Incoming stock
          automatically plus the lot you name. Scan a barcode here or on your phone.
        </p>
      </header>

      <div className="grid gap-4 lg:grid-cols-2">
        <ReceiveForm onUnknown={setUnknown} />
        <SaleForm onUnknown={setUnknown} />
      </div>

      <UnknownBarcode barcode={unknown} onClose={() => setUnknown(null)} />

      <Card className="p-0">
        <div className="border-b border-border px-5 py-4">
          <h2 className="font-display text-lg">Auto ledger</h2>
          <p className="text-sm text-muted">Every plus and minus the system just posted</p>
        </div>
        <ul className="divide-y divide-border">
          {ledger.isPending && <li className="px-5 py-8 text-sm text-muted">Loading…</li>}
          {ledger.data?.length === 0 && (
            <li className="px-5 py-8 text-sm text-muted">No in/out yet today.</li>
          )}
          {ledger.data?.map((row) => (
            <li key={row.id} className="flex flex-wrap items-baseline justify-between gap-3 px-5 py-3">
              <div className="min-w-0">
                <p className="text-sm">
                  <span className="capitalize">{row.kind === "sale" ? "Sale −" : "Stock in +"}</span>{" "}
                  <span className="font-mono text-xs text-muted">{row.sku}</span> {row.name}
                </p>
                <p className="font-mono text-xs text-subtle">
                  {row.lot_code}
                  {row.reason ? ` · ${row.reason}` : ""}
                </p>
              </div>
              <span
                className={`font-mono text-sm tabular-nums ${row.kind === "sale" ? "text-danger" : "text-ok"}`}
              >
                {row.qty > 0 ? `+${row.qty}` : row.qty}
              </span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

function ReceiveForm({ onUnknown }: { onUnknown: (code: string) => void }) {
  const qc = useQueryClient();
  const picked = useSkuPick(onUnknown);
  const [qty, setQty] = useState("10");
  const [lotCode, setLotCode] = useState("");
  const [expiresAt, setExpiresAt] = useState("");

  const mut = useMutation({
    mutationFn: () =>
      receiveStock({
        data: {
          itemId: picked.itemId,
          lotCode,
          qty: Number(qty),
          expiresAt: picked.hasExpiry ? expiresAt : null,
        },
      }),
    onSuccess: () => {
      toast.success(`+${qty} added to ${picked.sku}`);
      void qc.invalidateQueries();
      setQty("10");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Card>
      <p className="text-[11px] tracking-[0.14em] text-ok uppercase">Plus</p>
      <h2 className="mt-1 font-display text-xl">New stock in</h2>
      <p className="mt-1 text-sm text-muted">Receive from factory or supplier. Qty is added immediately.</p>
      <form
        className="mt-4 space-y-3"
        onSubmit={(e) => {
          e.preventDefault();
          mut.mutate();
        }}
      >
        <SkuField state={picked} />
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="in-qty">Quantity</Label>
            <Input id="in-qty" type="number" min={1} value={qty} onChange={(e) => setQty(e.target.value)} required />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="in-lot">Lot code</Label>
            <Input
              id="in-lot"
              value={lotCode}
              onChange={(e) => setLotCode(e.target.value)}
              placeholder="BULK"
              className="font-mono"
            />
          </div>
        </div>
        {picked.hasExpiry && (
          <div className="space-y-1.5">
            <Label htmlFor="in-exp">Expires</Label>
            <Input id="in-exp" type="date" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} required />
          </div>
        )}
        <Button type="submit" className="w-full" disabled={mut.isPending || !picked.itemId}>
          Add stock
        </Button>
      </form>
    </Card>
  );
}

function SaleForm({ onUnknown }: { onUnknown: (code: string) => void }) {
  const qc = useQueryClient();
  const picked = useSkuPick(onUnknown);
  const [qty, setQty] = useState("1");
  const [buyer, setBuyer] = useState("");
  const [orderRef, setOrderRef] = useState("");

  const mut = useMutation({
    mutationFn: () =>
      sellItem({
        data: {
          itemId: picked.itemId,
          qty: Number(qty),
          buyerName: buyer,
          orderRef,
        },
      }),
    onSuccess: (res) => {
      const lots = res.allocations.map((a) => `${a.qty} from ${a.lotCode}`).join(", ");
      toast.success(`−${qty} ${res.sku} · ${lots}`);
      void qc.invalidateQueries();
      setQty("1");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Card>
      <p className="text-[11px] tracking-[0.14em] text-danger uppercase">Minus</p>
      <h2 className="mt-1 font-display text-xl">Buyer purchase</h2>
      <p className="mt-1 text-sm text-muted">
        Deducts sellable stock automatically. Dated SKUs leave on the first-to-expire lot.
      </p>
      <form
        className="mt-4 space-y-3"
        onSubmit={(e) => {
          e.preventDefault();
          mut.mutate();
        }}
      >
        <SkuField state={picked} />
        <div className="space-y-1.5">
          <Label htmlFor="out-qty">Quantity</Label>
          <Input id="out-qty" type="number" min={1} value={qty} onChange={(e) => setQty(e.target.value)} required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="buyer">Buyer</Label>
            <Input id="buyer" value={buyer} onChange={(e) => setBuyer(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="so">Order / SO</Label>
            <Input id="so" value={orderRef} onChange={(e) => setOrderRef(e.target.value)} className="font-mono" />
          </div>
        </div>
        <Button type="submit" className="w-full" disabled={mut.isPending || !picked.itemId}>
          Record sale
        </Button>
      </form>
    </Card>
  );
}

function useSkuPick(onUnknown: (code: string) => void) {
  const [q, setQ] = useState("");
  const [itemId, setItemId] = useState("");
  const [sku, setSku] = useState("");
  const [hasExpiry, setHasExpiry] = useState(false);

  const applyItem = (item: { id: string; sku: string; name: string; hasExpiry: boolean }) => {
    setItemId(item.id);
    setSku(item.sku);
    setHasExpiry(item.hasExpiry);
    setQ(`${item.sku} · ${item.name}`);
  };

  const applyBarcode = async (code: string) => {
    const res = await lookupByBarcode({ data: code });
    if (res.item) {
      applyItem(res.item);
      toast.success(`Found ${res.item.sku}`);
    } else {
      onUnknown(code);
    }
  };

  const search = useQuery({
    queryKey: ["items", q, "", 0],
    queryFn: () => searchItems({ data: { q, page: 0 } }),
    enabled: q.length >= 1 && !itemId,
  });
  return {
    q,
    setQ,
    itemId,
    setItemId,
    sku,
    setSku,
    hasExpiry,
    setHasExpiry,
    search,
    applyItem,
    applyBarcode,
  };
}

function SkuField({ state }: { state: ReturnType<typeof useSkuPick> }) {
  const detail = useQuery({
    queryKey: ["item", state.itemId],
    queryFn: () => getItemDetail({ data: state.itemId }),
    enabled: Boolean(state.itemId),
  });

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between gap-2">
        <Label>SKU</Label>
        <ScanTrigger onCode={(code) => void state.applyBarcode(code)} label="Scan" />
      </div>
      <Input
        value={state.q}
        onChange={(e) => {
          state.setQ(e.target.value);
          state.setItemId("");
          state.setSku("");
        }}
        placeholder="Type SKU, name, or scan"
      />
      {state.search.data && !state.itemId && (
        <ul className="max-h-32 overflow-auto rounded-sm border border-border">
          {state.search.data.items.slice(0, 6).map((item) => (
            <li key={item.id}>
              <button
                type="button"
                className="w-full px-3 py-2 text-left text-sm hover:bg-elevated"
                onClick={() => state.applyItem(item)}
              >
                <span className="font-mono text-xs">{item.sku}</span> {item.name}
                <span className="ml-2 text-xs text-subtle">{item.available} available</span>
              </button>
            </li>
          ))}
        </ul>
      )}
      {state.itemId && detail.data && (
        <p className="text-xs text-muted">
          {detail.data.item.available} available · {detail.data.item.quarantined} held
        </p>
      )}
    </div>
  );
}

