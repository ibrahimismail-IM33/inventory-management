/** Prototype: skip sign-in. Set to `false` to bring the login screen back. */
export const PROTOTYPE_SKIP_AUTH = true;
