import type { Sql } from "@/lib/db";
import { isoDateOffset, nid } from "@/lib/utils";

type SeedCtx = { companyId: string; locationId: string; userId: string };

type SeedItem = {
  sku: string;
  name: string;
  category: string;
  barcode: string;
  unit: string;
  cost: number;
  hasExpiry: boolean;
  returnToFactory: boolean;
  lots: Array<{
    code: string;
    expiresIn: number | null;
    qty: number;
    status?: "ok" | "quarantined" | "in_transit_to_factory";
  }>;
};

const CATALOG: SeedItem[] = [
  {
    sku: "HX-M8-20",
    name: "Hex bolt M8 × 20",
    category: "Fasteners",
    barcode: "100000000001",
    unit: "ea",
    cost: 0.12,
    hasExpiry: false,
    returnToFactory: false,
    lots: [{ code: "BULK", expiresIn: null, qty: 4800 }],
  },
  {
    sku: "HX-M8-40",
    name: "Hex bolt M8 × 40",
    category: "Fasteners",
    barcode: "100000000002",
    unit: "ea",
    cost: 0.16,
    hasExpiry: false,
    returnToFactory: false,
    lots: [{ code: "BULK", expiresIn: null, qty: 2100 }],
  },
  {
    sku: "NT-M8",
    name: "Hex nut M8",
    category: "Fasteners",
    barcode: "100000000003",
    unit: "ea",
    cost: 0.08,
    hasExpiry: false,
    returnToFactory: false,
    lots: [{ code: "BULK", expiresIn: null, qty: 6400 }],
  },
  {
    sku: "WS-M8",
    name: "Flat washer M8",
    category: "Fasteners",
    barcode: "100000000004",
    unit: "ea",
    cost: 0.04,
    hasExpiry: false,
    returnToFactory: false,
    lots: [{ code: "BULK", expiresIn: null, qty: 9000 }],
  },
  {
    sku: "VL-BALL-25",
    name: "Brass ball valve 25 mm",
    category: "Plumbing",
    barcode: "100000000010",
    unit: "ea",
    cost: 18.4,
    hasExpiry: false,
    returnToFactory: true,
    lots: [{ code: "V25-2409", expiresIn: null, qty: 64 }],
  },
  {
    sku: "PP-2040",
    name: "PVC pressure pipe 20 × 40",
    category: "Plumbing",
    barcode: "100000000011",
    unit: "len",
    cost: 6.2,
    hasExpiry: false,
    returnToFactory: false,
    lots: [{ code: "EXT", expiresIn: null, qty: 180 }],
  },
  {
    sku: "PS-24V-5A",
    name: "DIN rail PSU 24 V 5 A",
    category: "Electronics",
    barcode: "200000000021",
    unit: "ea",
    cost: 42,
    hasExpiry: false,
    returnToFactory: true,
    lots: [
      { code: "PS-8841", expiresIn: null, qty: 28 },
      { code: "PS-8841-DMG", expiresIn: null, qty: 3, status: "quarantined" },
    ],
  },
  {
    sku: "SEN-PROX-M12",
    name: "Inductive proximity sensor M12",
    category: "Electronics",
    barcode: "200000000022",
    unit: "ea",
    cost: 27.5,
    hasExpiry: false,
    returnToFactory: true,
    lots: [
      { code: "PX-1102", expiresIn: null, qty: 40 },
      { code: "PX-1102-INB", expiresIn: null, qty: 2, status: "in_transit_to_factory" },
    ],
  },
  {
    sku: "CBL-USB-C-2",
    name: "USB-C cable 2 m",
    category: "Electronics",
    barcode: "200000000023",
    unit: "ea",
    cost: 3.1,
    hasExpiry: false,
    returnToFactory: false,
    lots: [{ code: "C2-17", expiresIn: null, qty: 220 }],
  },
  {
    sku: "BRD-CMP-4",
    name: "Single-board computer 4 GB",
    category: "Electronics",
    barcode: "200000000024",
    unit: "ea",
    cost: 68,
    hasExpiry: false,
    returnToFactory: true,
    lots: [{ code: "SB-440", expiresIn: null, qty: 16 }],
  },
  {
    sku: "FLT-HEPA-H13",
    name: "HEPA filter H13 600 mm",
    category: "Consumables",
    barcode: "300000000031",
    unit: "ea",
    cost: 22,
    hasExpiry: true,
    returnToFactory: false,
    lots: [
      { code: "HF-2501", expiresIn: 45, qty: 36 },
      { code: "HF-2411", expiresIn: 12, qty: 8 },
    ],
  },
  {
    sku: "LUB-FG-1L",
    name: "Food-grade lubricant 1 L",
    category: "Consumables",
    barcode: "300000000032",
    unit: "btl",
    cost: 14.8,
    hasExpiry: true,
    returnToFactory: true,
    lots: [{ code: "FG-0819", expiresIn: 18, qty: 24 }],
  },
  {
    sku: "RGT-PH7",
    name: "pH 7 calibration buffer 250 ml",
    category: "Lab",
    barcode: "300000000033",
    unit: "btl",
    cost: 9.4,
    hasExpiry: true,
    returnToFactory: true,
    lots: [
      { code: "PH7-A", expiresIn: 20, qty: 18 },
      { code: "PH7-B", expiresIn: 4, qty: 6 },
    ],
  },
  {
    sku: "RGT-PH4",
    name: "pH 4 calibration buffer 250 ml",
    category: "Lab",
    barcode: "300000000034",
    unit: "btl",
    cost: 9.4,
    hasExpiry: true,
    returnToFactory: true,
    lots: [{ code: "PH4-A", expiresIn: 6, qty: 11 }],
  },
  {
    sku: "ADH-EPX-50",
    name: "Two-part epoxy 50 ml",
    category: "Consumables",
    barcode: "300000000035",
    unit: "kit",
    cost: 7.2,
    hasExpiry: true,
    returnToFactory: false,
    lots: [{ code: "EP-0622", expiresIn: -2, qty: 9 }],
  },
  {
    sku: "BAT-LI-18650",
    name: "Li-ion cell 18650 3.5 Ah",
    category: "Electronics",
    barcode: "300000000036",
    unit: "ea",
    cost: 4.8,
    hasExpiry: true,
    returnToFactory: true,
    lots: [{ code: "LI-2601", expiresIn: 400, qty: 200 }],
  },
  {
    sku: "MLK-1L",
    name: "Whole milk 1 L",
    category: "Perishable",
    barcode: "400000000041",
    unit: "ctn",
    cost: 1.35,
    hasExpiry: true,
    returnToFactory: false,
    lots: [
      { code: "MK-0819", expiresIn: 3, qty: 48 },
      { code: "MK-0822", expiresIn: 8, qty: 72 },
    ],
  },
  {
    sku: "YGR-PLN-500",
    name: "Plain yogurt 500 g",
    category: "Perishable",
    barcode: "400000000042",
    unit: "cup",
    cost: 1.1,
    hasExpiry: true,
    returnToFactory: false,
    lots: [{ code: "YG-0821", expiresIn: 5, qty: 36 }],
  },
  {
    sku: "COF-BEAN-1KG",
    name: "Coffee beans 1 kg",
    category: "Grocery",
    barcode: "400000000043",
    unit: "bag",
    cost: 11.5,
    hasExpiry: true,
    returnToFactory: false,
    lots: [{ code: "CF-2506", expiresIn: 90, qty: 40 }],
  },
  {
    sku: "GLV-NIT-M",
    name: "Nitrile gloves M, box 100",
    category: "Consumables",
    barcode: "300000000037",
    unit: "box",
    cost: 6.4,
    hasExpiry: true,
    returnToFactory: false,
    lots: [{ code: "GL-25", expiresIn: 220, qty: 85 }],
  },
];

export async function seedCompany(sql: Sql, ctx: SeedCtx): Promise<void> {
  for (const item of CATALOG) {
    const itemId = nid("it");
    await sql`
      insert into items (
        id, company_id, sku, name, category, barcode, unit, cost, sell_price,
        has_expiry, return_to_factory, status
      ) values (
        ${itemId}, ${ctx.companyId}, ${item.sku}, ${item.name}, ${item.category},
        ${item.barcode}, ${item.unit}, ${item.cost}, ${Math.round(item.cost * 165) / 100},
        ${item.hasExpiry}, ${item.returnToFactory}, 'active'
      )
    `;
    for (const lot of item.lots) {
      const lotId = nid("lt");
      const expires = lot.expiresIn === null ? null : isoDateOffset(lot.expiresIn);
      const status = lot.status ?? lotStatusFromOffset(lot.expiresIn);
      await sql`
        insert into lots (id, company_id, item_id, lot_code, expires_at, status)
        values (${lotId}, ${ctx.companyId}, ${itemId}, ${lot.code}, ${expires}, ${status})
      `;
      await sql`
        insert into stock (company_id, lot_id, location_id, qty)
        values (${ctx.companyId}, ${lotId}, ${ctx.locationId}, ${lot.qty})
      `;
      await sql`
        insert into stock_movements (
          id, company_id, item_id, lot_id, location_id, kind, qty, reason, actor_id
        ) values (
          ${nid("mv")}, ${ctx.companyId}, ${itemId}, ${lotId}, ${ctx.locationId},
          'receive', ${lot.qty}, 'Opening balance', ${ctx.userId}
        )
      `;
    }
  }

  const psu = await sql<{ id: string }>`
    select id from items where company_id = ${ctx.companyId} and sku = 'PS-24V-5A' limit 1
  `;
  const psuLot = await sql<{ id: string }>`
    select id from lots
    where company_id = ${ctx.companyId} and item_id = ${psu[0]?.id ?? ""} and lot_code = 'PS-8841-DMG'
    limit 1
  `;
  if (psu[0] && psuLot[0]) {
    await sql`
      insert into buyer_returns (
        id, company_id, item_id, lot_id, location_id, qty, damage_code,
        buyer_name, order_ref, decision, outcome, notes, actor_id
      ) values (
        ${nid("br")}, ${ctx.companyId}, ${psu[0].id}, ${psuLot[0].id}, ${ctx.locationId},
        3, 'DOA', 'Harbor Electric', 'SO-10482', 'refund', 'quarantine',
        'Units dead on first power-up. Hold for factory RMA.', ${ctx.userId}
      )
    `;
  }

  const sen = await sql<{ id: string }>`
    select id from items where company_id = ${ctx.companyId} and sku = 'SEN-PROX-M12' limit 1
  `;
  const senLot = await sql<{ id: string }>`
    select id from lots
    where company_id = ${ctx.companyId} and item_id = ${sen[0]?.id ?? ""} and lot_code = 'PX-1102-INB'
    limit 1
  `;
  if (sen[0] && senLot[0]) {
    const rtvId = nid("rtv");
    await sql`
      insert into factory_returns (
        id, company_id, vendor_name, rma_number, status, notes, actor_id
      ) values (
        ${rtvId}, ${ctx.companyId}, 'Omnex Sensing', 'RMA-7721', 'shipped',
        'Inbound carton crushed. Two sensors cracked.', ${ctx.userId}
      )
    `;
    await sql`
      insert into factory_return_lines (
        id, factory_return_id, company_id, item_id, lot_id, location_id, qty, damage_code
      ) values (
        ${nid("rl")}, ${rtvId}, ${ctx.companyId}, ${sen[0].id}, ${senLot[0].id},
        ${ctx.locationId}, 2, 'INBOUND_DAMAGED'
      )
    `;
  }
}

function lotStatusFromOffset(offset: number | null): string {
  if (offset === null) return "ok";
  if (offset < 0) return "expired";
  if (offset <= 7) return "expiring_soon";
  return "ok";
}
