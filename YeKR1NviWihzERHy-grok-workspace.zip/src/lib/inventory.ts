import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { requireWorkspace } from "@/lib/tenant";
import { daysUntil, nid } from "@/lib/utils";

const PAGE = 25;

type ItemRow = {
  id: string;
  sku: string;
  name: string;
  category: string;
  barcode: string | null;
  unit: string;
  cost: string;
  sell_price: string;
  has_expiry: boolean;
  return_to_factory: boolean;
  status: string;
  on_hand: number;
  available: number;
  quarantined: number;
  expires_at?: string | null;
};

type LotRow = {
  id: string;
  lot_code: string;
  expires_at: string | null;
  status: string;
  qty: number;
};

export const getWorkspaceOverview = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    await syncLotStatuses(ws.companyId);

    const skuCount = await sql<{ n: number }>`
      select count(*)::int as n from items where company_id = ${ws.companyId}
    `;
    const stock = await sql<{ on_hand: number; available: number; quarantined: number }>`
      select
        coalesce(sum(s.qty), 0)::int as on_hand,
        coalesce(sum(s.qty) filter (where l.status in ('ok', 'expiring_soon')), 0)::int as available,
        coalesce(sum(s.qty) filter (where l.status = 'quarantined'), 0)::int as quarantined
      from stock s
      join lots l on l.id = s.lot_id
      where s.company_id = ${ws.companyId}
    `;
    const expiring = await sql<{ n: number }>`
      select count(*)::int as n
      from lots
      where company_id = ${ws.companyId}
        and expires_at is not null
        and expires_at <= (current_date + 14)
        and status in ('ok', 'expiring_soon', 'expired')
    `;
    const expired = await sql<{ n: number }>`
      select count(*)::int as n
      from lots
      where company_id = ${ws.companyId} and status = 'expired'
    `;
    const openRtv = await sql<{ n: number }>`
      select count(*)::int as n
      from factory_returns
      where company_id = ${ws.companyId}
        and status in ('draft', 'submitted', 'shipped')
    `;
    const buyerOpen = await sql<{ n: number }>`
      select count(*)::int as n
      from buyer_returns
      where company_id = ${ws.companyId} and factory_return_id is null
        and outcome = 'quarantine'
    `;
    const soon = await sql<{
      id: string;
      item_id: string;
      sku: string;
      name: string;
      lot_code: string;
      expires_at: string;
      status: string;
      qty: number;
    }>`
      select l.id, i.id as item_id, i.sku, i.name, l.lot_code, l.expires_at, l.status, coalesce(s.qty, 0)::int as qty
      from lots l
      join items i on i.id = l.item_id
      left join stock s on s.lot_id = l.id
      where l.company_id = ${ws.companyId}
        and l.expires_at is not null
        and l.status in ('ok', 'expiring_soon', 'expired')
      order by l.expires_at asc
      limit 6
    `;
    const recent = await sql<{
      id: string;
      item_id: string;
      kind: string;
      qty: number;
      reason: string | null;
      sku: string;
      created_at: string;
    }>`
      select m.id, m.item_id, m.kind, m.qty, m.reason, i.sku, m.created_at::text as created_at
      from stock_movements m
      join items i on i.id = m.item_id
      where m.company_id = ${ws.companyId}
      order by m.created_at desc
      limit 8
    `;

    const today = await sql<{ received: number; sold: number; profit: string }>`
      select
        coalesce(sum(m.qty) filter (where m.kind = 'receive' and coalesce(m.reason, '') <> 'Opening balance'), 0)::int as received,
        coalesce(sum(-m.qty) filter (where m.kind = 'sale'), 0)::int as sold,
        coalesce(sum((-m.qty) * (i.sell_price - i.cost)) filter (where m.kind = 'sale'), 0)::text as profit
      from stock_movements m
      join items i on i.id = m.item_id
      where m.company_id = ${ws.companyId}
        and m.created_at >= current_date
    `;

    const margin = await sql<{ on_hand: string }>`
      select coalesce(sum(s.qty * (i.sell_price - i.cost)) filter (where l.status in ('ok', 'expiring_soon')), 0)::text as on_hand
      from stock s
      join lots l on l.id = s.lot_id
      join items i on i.id = l.item_id
      where s.company_id = ${ws.companyId}
    `;

    return {
      workspace: ws,
      stats: {
        skus: skuCount[0]?.n ?? 0,
        onHand: stock[0]?.on_hand ?? 0,
        available: stock[0]?.available ?? 0,
        quarantined: stock[0]?.quarantined ?? 0,
        expiringLots: expiring[0]?.n ?? 0,
        expiredLots: expired[0]?.n ?? 0,
        openRtv: openRtv[0]?.n ?? 0,
        buyerOpen: buyerOpen[0]?.n ?? 0,
        receivedToday: today[0]?.received ?? 0,
        soldToday: today[0]?.sold ?? 0,
        profitToday: Number(today[0]?.profit ?? 0),
        profitOnHand: Number(margin[0]?.on_hand ?? 0),
      },
      expiring: soon.map((row) => ({
        ...row,
        daysLeft: daysUntil(row.expires_at),
      })),
      recent,
    };
  });

export const searchItems = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((input: { q?: string; category?: string; page?: number }) => ({
    q: (input.q ?? "").trim(),
    category: (input.category ?? "").trim(),
    page: Math.max(0, Number(input.page ?? 0) || 0),
  }))
  .handler(async ({ context, data }) => {
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    const like = `%${data.q.toLowerCase()}%`;
    const offset = data.page * PAGE;

    const rows = await sql<ItemRow>`
      select
        i.id, i.sku, i.name, i.category, i.barcode, i.unit, i.cost::text as cost,
        i.sell_price::text as sell_price,
        i.has_expiry, i.return_to_factory, i.status,
        coalesce(sum(s.qty), 0)::int as on_hand,
        coalesce(sum(s.qty) filter (where l.status in ('ok', 'expiring_soon')), 0)::int as available,
        coalesce(sum(s.qty) filter (where l.status = 'quarantined'), 0)::int as quarantined,
        min(l.expires_at) filter (where coalesce(s.qty, 0) > 0 and l.expires_at is not null) as expires_at,
        min(l.expires_at) filter (where coalesce(s.qty, 0) > 0 and l.expires_at is not null) as expires_at
      from items i
      left join lots l on l.item_id = i.id
      left join stock s on s.lot_id = l.id
      where i.company_id = ${ws.companyId}
        and (${data.q} = '' or lower(i.sku) like ${like} or lower(i.name) like ${like} or i.barcode like ${like})
        and (${data.category} = '' or i.category = ${data.category})
      group by i.id
      order by i.sku asc
      limit ${PAGE} offset ${offset}
    `;
    const total = await sql<{ n: number }>`
      select count(*)::int as n
      from items i
      where i.company_id = ${ws.companyId}
        and (${data.q} = '' or lower(i.sku) like ${like} or lower(i.name) like ${like} or i.barcode like ${like})
        and (${data.category} = '' or i.category = ${data.category})
    `;
    const cats = await sql<{ category: string }>`
      select distinct category from items where company_id = ${ws.companyId} order by category
    `;
    return {
      items: rows.map(shapeItem),
      total: total[0]?.n ?? 0,
      page: data.page,
      pageSize: PAGE,
      categories: cats.map((c) => c.category),
    };
  });

export const getItemDetail = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    await syncLotStatuses(ws.companyId);
    const items = await sql<ItemRow>`
      select
        i.id, i.sku, i.name, i.category, i.barcode, i.unit, i.cost::text as cost,
        i.sell_price::text as sell_price,
        i.has_expiry, i.return_to_factory, i.status,
        coalesce(sum(s.qty), 0)::int as on_hand,
        coalesce(sum(s.qty) filter (where l.status in ('ok', 'expiring_soon')), 0)::int as available,
        coalesce(sum(s.qty) filter (where l.status = 'quarantined'), 0)::int as quarantined,
        min(l.expires_at) filter (where coalesce(s.qty, 0) > 0 and l.expires_at is not null) as expires_at
      from items i
      left join lots l on l.item_id = i.id
      left join stock s on s.lot_id = l.id
      where i.company_id = ${ws.companyId} and i.id = ${id}
      group by i.id
    `;
    if (!items[0]) throw new Error("SKU not found");
    const lots = await sql<LotRow>`
      select l.id, l.lot_code, l.expires_at, l.status, coalesce(s.qty, 0)::int as qty
      from lots l
      left join stock s on s.lot_id = l.id
      where l.company_id = ${ws.companyId} and l.item_id = ${id}
      order by l.expires_at nulls last, l.created_at desc
    `;
    const movements = await sql<{
      id: string;
      kind: string;
      qty: number;
      reason: string | null;
      lot_code: string;
      created_at: string;
    }>`
      select m.id, m.kind, m.qty, m.reason, l.lot_code, m.created_at::text as created_at
      from stock_movements m
      join lots l on l.id = m.lot_id
      where m.company_id = ${ws.companyId} and m.item_id = ${id}
      order by m.created_at desc
      limit 20
    `;
    return {
      item: shapeItem(items[0]),
      lots: lots.map((lot) => ({ ...lot, daysLeft: daysUntil(lot.expires_at) })),
      movements,
      locationName: ws.locationName,
    };
  });

export const createItem = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    sku: string;
    name: string;
    category: string;
    barcode?: string;
    unit?: string;
    cost?: number;
    sellPrice?: number;
    hasExpiry?: boolean;
    returnToFactory?: boolean;
    openingQty?: number;
    lotCode?: string;
    expiresAt?: string | null;
  }) => ({
    sku: input.sku.trim().toUpperCase(),
    name: input.name.trim(),
    category: input.category.trim() || "General",
    barcode: input.barcode?.trim() || null,
    unit: input.unit?.trim() || "ea",
    cost: Number(input.cost ?? 0) || 0,
    sellPrice: Number(input.sellPrice ?? 0) || 0,
    hasExpiry: Boolean(input.hasExpiry),
    returnToFactory: input.returnToFactory !== false,
    openingQty: Math.max(0, Math.floor(Number(input.openingQty ?? 0) || 0)),
    lotCode: input.lotCode?.trim().toUpperCase() || "OPEN",
    expiresAt: input.expiresAt?.slice(0, 10) || null,
  }))
  .handler(async ({ context, data }) => {
    if (!data.sku || !data.name) throw new Error("SKU and name are required");
    if (data.hasExpiry && data.openingQty > 0 && !data.expiresAt) {
      throw new Error("First lot needs an expiry date");
    }
    const ws = await requireWorkspace(context.userId);
    return insertCatalogItem(ws, context.userId, data);
  });

export const importItems = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    rows: Array<{
      sku: string;
      name: string;
      category?: string;
      barcode?: string;
      unit?: string;
      cost?: number;
      sellPrice?: number;
      hasExpiry?: boolean;
      returnToFactory?: boolean;
      openingQty?: number;
      lotCode?: string;
      expiresAt?: string | null;
    }>;
  }) => ({
    rows: input.rows.slice(0, 500).map((row) => ({
      sku: String(row.sku ?? "").trim().toUpperCase(),
      name: String(row.name ?? "").trim(),
      category: String(row.category ?? "").trim() || "General",
      barcode: String(row.barcode ?? "").trim() || null,
      unit: String(row.unit ?? "").trim() || "ea",
      cost: Number(row.cost ?? 0) || 0,
      sellPrice: Number(row.sellPrice ?? 0) || 0,
      hasExpiry: Boolean(row.hasExpiry),
      returnToFactory: row.returnToFactory !== false,
      openingQty: Math.max(0, Math.floor(Number(row.openingQty ?? 0) || 0)),
      lotCode: String(row.lotCode ?? "").trim().toUpperCase() || "OPEN",
      expiresAt: row.expiresAt ? String(row.expiresAt).slice(0, 10) : null,
    })),
  }))
  .handler(async ({ context, data }) => {
    const ws = await requireWorkspace(context.userId);
    let created = 0;
    const errors: string[] = [];
    for (const row of data.rows) {
      if (!row.sku || !row.name) {
        errors.push(`${row.sku || "(blank)"}: SKU and name are required`);
        continue;
      }
      if (row.hasExpiry && row.openingQty > 0 && !row.expiresAt) {
        errors.push(`${row.sku}: dated opening stock needs expires_at`);
        continue;
      }
      try {
        await insertCatalogItem(ws, context.userId, row);
        created += 1;
      } catch (err) {
        errors.push(`${row.sku}: ${err instanceof Error ? err.message : "failed"}`);
      }
    }
    return { created, skipped: data.rows.length - created, errors: errors.slice(0, 20) };
  });

async function insertCatalogItem(
  ws: { companyId: string; locationId: string },
  userId: string,
  data: {
    sku: string;
    name: string;
    category: string;
    barcode: string | null;
    unit: string;
    cost: number;
    sellPrice: number;
    hasExpiry: boolean;
    returnToFactory: boolean;
    openingQty: number;
    lotCode: string;
    expiresAt: string | null;
  },
) {
  const sql = await getSql();
  const id = nid("it");
  try {
    await sql`
      insert into items (
        id, company_id, sku, name, category, barcode, unit, cost, sell_price,
        has_expiry, return_to_factory
      ) values (
        ${id}, ${ws.companyId}, ${data.sku}, ${data.name}, ${data.category},
        ${data.barcode}, ${data.unit}, ${data.cost}, ${data.sellPrice},
        ${data.hasExpiry}, ${data.returnToFactory}
      )
    `;
  } catch {
    throw new Error("SKU or barcode already exists");
  }
  if (data.openingQty > 0) {
    const expires = data.hasExpiry ? data.expiresAt : null;
    const lotId = nid("lt");
    const status = expires ? statusFromDate(expires) : "ok";
    await sql`
      insert into lots (id, company_id, item_id, lot_code, expires_at, status)
      values (${lotId}, ${ws.companyId}, ${id}, ${data.lotCode}, ${expires}, ${status})
    `;
    await sql`
      insert into stock (company_id, lot_id, location_id, qty)
      values (${ws.companyId}, ${lotId}, ${ws.locationId}, ${data.openingQty})
    `;
    await sql`
      insert into stock_movements (
        id, company_id, item_id, lot_id, location_id, kind, qty, reason, actor_id
      ) values (
        ${nid("mv")}, ${ws.companyId}, ${id}, ${lotId}, ${ws.locationId},
        'receive', ${data.openingQty}, 'CSV import', ${userId}
      )
    `;
  }
  return { id };
}

export const receiveStock = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    itemId: string;
    lotCode: string;
    qty: number;
    expiresAt?: string | null;
  }) => ({
    itemId: input.itemId,
    lotCode: input.lotCode.trim().toUpperCase() || "BULK",
    qty: Math.floor(Number(input.qty)),
    expiresAt: input.expiresAt?.slice(0, 10) || null,
  }))
  .handler(async ({ context, data }) => {
    if (data.qty <= 0) throw new Error("Quantity must be positive");
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    const item = await sql<{ id: string; has_expiry: boolean }>`
      select id, has_expiry from items
      where id = ${data.itemId} and company_id = ${ws.companyId}
    `;
    if (!item[0]) throw new Error("SKU not found");
    const expires = item[0].has_expiry ? data.expiresAt : null;
    const existing = await sql<{ id: string; status: string }>`
      select id, status from lots
      where company_id = ${ws.companyId} and item_id = ${data.itemId} and lot_code = ${data.lotCode}
    `;
    let lotId = existing[0]?.id;
    if (!lotId) {
      lotId = nid("lt");
      const status = expires ? statusFromDate(expires) : "ok";
      await sql`
        insert into lots (id, company_id, item_id, lot_code, expires_at, status)
        values (${lotId}, ${ws.companyId}, ${data.itemId}, ${data.lotCode}, ${expires}, ${status})
      `;
    } else if (existing[0]?.status === "written_off") {
      const status = expires ? statusFromDate(expires) : "ok";
      await sql`
        update lots set status = ${status}, expires_at = coalesce(${expires}, expires_at)
        where id = ${lotId} and company_id = ${ws.companyId}
      `;
    }
    await upsertStock(ws.companyId, lotId, ws.locationId, data.qty);
    await sql`
      insert into stock_movements (
        id, company_id, item_id, lot_id, location_id, kind, qty, reason, actor_id
      ) values (
        ${nid("mv")}, ${ws.companyId}, ${data.itemId}, ${lotId}, ${ws.locationId},
        'receive', ${data.qty}, 'Received into warehouse', ${context.userId}
      )
    `;
    return { lotId };
  });

export const quarantineStock = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { lotId: string; qty: number; damageCode: string; reason?: string }) => ({
    lotId: input.lotId,
    qty: Math.floor(Number(input.qty)),
    damageCode: input.damageCode,
    reason: input.reason?.trim() || null,
  }))
  .handler(async ({ context, data }) => {
    if (data.qty <= 0) throw new Error("Quantity must be positive");
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    const lot = await sql<{
      id: string;
      item_id: string;
      lot_code: string;
      expires_at: string | null;
      status: string;
      qty: number;
    }>`
      select l.id, l.item_id, l.lot_code, l.expires_at, l.status, coalesce(s.qty, 0)::int as qty
      from lots l
      left join stock s on s.lot_id = l.id and s.location_id = ${ws.locationId}
      where l.id = ${data.lotId} and l.company_id = ${ws.companyId}
    `;
    if (!lot[0]) throw new Error("Lot not found");
    if (data.qty > lot[0].qty) throw new Error("Not enough units on this lot");
    if (lot[0].status === "in_transit_to_factory" || lot[0].status === "written_off") {
      throw new Error("This lot is already leaving stock");
    }

    let destLotId = lot[0].id;
    if (data.qty === lot[0].qty) {
      await sql`
        update lots set status = 'quarantined'
        where id = ${lot[0].id} and company_id = ${ws.companyId}
      `;
    } else {
      destLotId = nid("lt");
      const code = `${lot[0].lot_code}-Q${Date.now().toString().slice(-4)}`;
      await sql`
        insert into lots (id, company_id, item_id, lot_code, expires_at, status)
        values (${destLotId}, ${ws.companyId}, ${lot[0].item_id}, ${code}, ${lot[0].expires_at}, 'quarantined')
      `;
      await sql`
        update stock set qty = qty - ${data.qty}
        where lot_id = ${lot[0].id} and location_id = ${ws.locationId} and company_id = ${ws.companyId}
      `;
      await sql`
        insert into stock (company_id, lot_id, location_id, qty)
        values (${ws.companyId}, ${destLotId}, ${ws.locationId}, ${data.qty})
      `;
    }
    await sql`
      insert into stock_movements (
        id, company_id, item_id, lot_id, location_id, kind, qty, reason, actor_id
      ) values (
        ${nid("mv")}, ${ws.companyId}, ${lot[0].item_id}, ${destLotId}, ${ws.locationId},
        'quarantine', ${-data.qty}, ${data.reason ?? data.damageCode}, ${context.userId}
      )
    `;
    return { lotId: destLotId };
  });

export const listExpiring = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    await syncLotStatuses(ws.companyId);
    const rows = await sql<{
      id: string;
      item_id: string;
      sku: string;
      name: string;
      lot_code: string;
      expires_at: string;
      status: string;
      qty: number;
      return_to_factory: boolean;
    }>`
      select
        l.id, i.id as item_id, i.sku, i.name, l.lot_code, l.expires_at, l.status,
        coalesce(s.qty, 0)::int as qty, i.return_to_factory
      from lots l
      join items i on i.id = l.item_id
      left join stock s on s.lot_id = l.id
      where l.company_id = ${ws.companyId}
        and l.expires_at is not null
        and l.status not in ('written_off')
      order by l.expires_at asc
    `;
    return rows.map((row) => ({ ...row, daysLeft: daysUntil(row.expires_at) }));
  });

export const listQuarantine = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    return sql<{
      id: string;
      item_id: string;
      sku: string;
      name: string;
      lot_code: string;
      expires_at: string | null;
      qty: number;
      return_to_factory: boolean;
    }>`
      select
        l.id, i.id as item_id, i.sku, i.name, l.lot_code, l.expires_at,
        coalesce(s.qty, 0)::int as qty, i.return_to_factory
      from lots l
      join items i on i.id = l.item_id
      left join stock s on s.lot_id = l.id
      where l.company_id = ${ws.companyId} and l.status = 'quarantined' and coalesce(s.qty, 0) > 0
      order by l.created_at desc
    `;
  });

export const listBuyerReturns = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    return sql<{
      id: string;
      sku: string;
      name: string;
      lot_code: string;
      qty: number;
      damage_code: string;
      buyer_name: string | null;
      order_ref: string | null;
      decision: string;
      outcome: string;
      created_at: string;
    }>`
      select
        r.id, i.sku, i.name, l.lot_code, r.qty, r.damage_code,
        r.buyer_name, r.order_ref, r.decision, r.outcome,
        r.created_at::text as created_at
      from buyer_returns r
      join items i on i.id = r.item_id
      join lots l on l.id = r.lot_id
      where r.company_id = ${ws.companyId}
      order by r.created_at desc
    `;
  });

export const createBuyerReturn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    itemId: string;
    lotId: string;
    qty: number;
    damageCode: string;
    buyerName?: string;
    orderRef?: string;
    decision?: string;
    notes?: string;
  }) => ({
    itemId: input.itemId,
    lotId: input.lotId,
    qty: Math.floor(Number(input.qty)),
    damageCode: input.damageCode,
    buyerName: input.buyerName?.trim() || null,
    orderRef: input.orderRef?.trim() || null,
    decision: input.decision === "replace" ? "replace" : "refund",
    notes: input.notes?.trim() || null,
  }))
  .handler(async ({ context, data }) => {
    if (data.qty <= 0) throw new Error("Quantity must be positive");
    const allowed = ["DOA", "TRANSIT_BROKEN", "MISSING_PARTS", "WRONG_ITEM"];
    if (!allowed.includes(data.damageCode)) throw new Error("Invalid damage code");
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    const lot = await sql<{
      id: string;
      item_id: string;
      lot_code: string;
      expires_at: string | null;
      status: string;
    }>`
      select id, item_id, lot_code, expires_at, status
      from lots
      where id = ${data.lotId} and item_id = ${data.itemId} and company_id = ${ws.companyId}
    `;
    if (!lot[0]) throw new Error("Lot not found for this SKU");

    const destLotId = nid("lt");
    const code = `${lot[0].lot_code}-RTN`;
    await sql`
      insert into lots (id, company_id, item_id, lot_code, expires_at, status)
      values (${destLotId}, ${ws.companyId}, ${data.itemId}, ${code}, ${lot[0].expires_at}, 'quarantined')
      on conflict (company_id, item_id, lot_code) do nothing
    `;
    const dest = await sql<{ id: string }>`
      select id from lots
      where company_id = ${ws.companyId} and item_id = ${data.itemId} and lot_code = ${code}
    `;
    const holdId = dest[0]?.id ?? destLotId;
    await sql`update lots set status = 'quarantined' where id = ${holdId} and company_id = ${ws.companyId}`;
    await upsertStock(ws.companyId, holdId, ws.locationId, data.qty);
    await sql`
      insert into stock_movements (
        id, company_id, item_id, lot_id, location_id, kind, qty, reason, actor_id
      ) values (
        ${nid("mv")}, ${ws.companyId}, ${data.itemId}, ${holdId}, ${ws.locationId},
        'buyer_return', ${data.qty}, ${data.damageCode}, ${context.userId}
      )
    `;
    const id = nid("br");
    await sql`
      insert into buyer_returns (
        id, company_id, item_id, lot_id, location_id, qty, damage_code,
        buyer_name, order_ref, decision, outcome, notes, actor_id
      ) values (
        ${id}, ${ws.companyId}, ${data.itemId}, ${holdId}, ${ws.locationId}, ${data.qty},
        ${data.damageCode}, ${data.buyerName}, ${data.orderRef}, ${data.decision},
        'quarantine', ${data.notes}, ${context.userId}
      )
    `;
    let allocations: Array<{ lotCode: string; qty: number }> = [];
    if (data.decision === "replace") {
      allocations = await takeAvailable({
        companyId: ws.companyId,
        locationId: ws.locationId,
        itemId: data.itemId,
        qty: data.qty,
        actorId: context.userId,
        reason: `Replacement for ${data.orderRef ?? "buyer return"}`,
      });
    }
    return { id, allocations };
  });

export const listFactoryReturns = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    const headers = await sql<{
      id: string;
      vendor_name: string;
      rma_number: string | null;
      status: string;
      credit_amount: string | null;
      notes: string | null;
      created_at: string;
    }>`
      select id, vendor_name, rma_number, status, credit_amount::text as credit_amount,
             notes, created_at::text as created_at
      from factory_returns
      where company_id = ${ws.companyId}
      order by created_at desc
    `;
    const lines = await sql<{
      factory_return_id: string;
      sku: string;
      name: string;
      lot_code: string;
      qty: number;
      damage_code: string;
    }>`
      select fl.factory_return_id, i.sku, i.name, l.lot_code, fl.qty, fl.damage_code
      from factory_return_lines fl
      join items i on i.id = fl.item_id
      join lots l on l.id = fl.lot_id
      where fl.company_id = ${ws.companyId}
    `;
    return headers.map((h) => ({
      ...h,
      lines: lines.filter((ln) => ln.factory_return_id === h.id),
    }));
  });

export const createFactoryReturn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    vendorName: string;
    rmaNumber?: string;
    notes?: string;
    lines: Array<{ lotId: string; damageCode: string }>;
  }) => ({
    vendorName: input.vendorName.trim(),
    rmaNumber: input.rmaNumber?.trim() || null,
    notes: input.notes?.trim() || null,
    lines: input.lines,
  }))
  .handler(async ({ context, data }) => {
    if (!data.vendorName) throw new Error("Vendor / factory name is required");
    if (!data.lines.length) throw new Error("Pick at least one quarantined lot");
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    const rtvId = nid("rtv");
    await sql`
      insert into factory_returns (
        id, company_id, vendor_name, rma_number, status, notes, actor_id
      ) values (
        ${rtvId}, ${ws.companyId}, ${data.vendorName}, ${data.rmaNumber}, 'submitted',
        ${data.notes}, ${context.userId}
      )
    `;
    for (const line of data.lines) {
      const lot = await sql<{
        id: string;
        item_id: string;
        status: string;
        qty: number;
        expires_at: string | null;
        return_to_factory: boolean;
      }>`
        select l.id, l.item_id, l.status, coalesce(s.qty, 0)::int as qty, l.expires_at, i.return_to_factory
        from lots l
        join items i on i.id = l.item_id
        left join stock s on s.lot_id = l.id and s.location_id = ${ws.locationId}
        where l.id = ${line.lotId} and l.company_id = ${ws.companyId}
      `;
      const row = lot[0];
      if (!row || row.status !== "quarantined" || row.qty <= 0) {
        throw new Error("Only quarantined lots with quantity can go to the factory");
      }
      if (!row.return_to_factory) {
        throw new Error("This SKU is scrap-only — do not ship it back to the factory");
      }
      const left = daysUntil(row.expires_at);
      if (left !== null && left < 30) {
        throw new Error("Lot expires within 30 days — scrap it, the factory will reject it");
      }
      await sql`
        insert into factory_return_lines (
          id, factory_return_id, company_id, item_id, lot_id, location_id, qty, damage_code
        ) values (
          ${nid("rl")}, ${rtvId}, ${ws.companyId}, ${row.item_id}, ${row.id},
          ${ws.locationId}, ${row.qty}, ${line.damageCode}
        )
      `;
      await sql`
        update lots set status = 'in_transit_to_factory'
        where id = ${row.id} and company_id = ${ws.companyId}
      `;
      await sql`
        insert into stock_movements (
          id, company_id, item_id, lot_id, location_id, kind, qty, reason, actor_id
        ) values (
          ${nid("mv")}, ${ws.companyId}, ${row.item_id}, ${row.id}, ${ws.locationId},
          'rtv_ship', ${-row.qty}, 'Submitted to factory', ${context.userId}
        )
      `;
    }
    return { id: rtvId };
  });

export const updateFactoryReturn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; status: "shipped" | "credited" | "replaced" | "rejected"; creditAmount?: number }) => ({
    id: input.id,
    status: input.status,
    creditAmount: input.creditAmount ?? null,
  }))
  .handler(async ({ context, data }) => {
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    const current = await sql<{ id: string; status: string }>`
      select id, status from factory_returns
      where id = ${data.id} and company_id = ${ws.companyId}
    `;
    if (!current[0]) throw new Error("Factory return not found");
    await sql`
      update factory_returns
      set status = ${data.status},
          credit_amount = coalesce(${data.creditAmount}, credit_amount),
          updated_at = now()
      where id = ${data.id} and company_id = ${ws.companyId}
    `;
    if (data.status === "credited" || data.status === "replaced" || data.status === "rejected") {
      const lines = await sql<{ lot_id: string; item_id: string; qty: number }>`
        select lot_id, item_id, qty from factory_return_lines
        where factory_return_id = ${data.id} and company_id = ${ws.companyId}
      `;
      for (const line of lines) {
        await sql`
          update lots set status = 'written_off'
          where id = ${line.lot_id} and company_id = ${ws.companyId}
        `;
        await sql`
          update stock set qty = 0
          where lot_id = ${line.lot_id} and company_id = ${ws.companyId}
        `;
        await sql`
          insert into stock_movements (
            id, company_id, item_id, lot_id, location_id, kind, qty, reason, actor_id
          ) values (
            ${nid("mv")}, ${ws.companyId}, ${line.item_id}, ${line.lot_id}, ${ws.locationId},
            ${data.status === "rejected" ? "scrap" : "write_off"},
            ${-line.qty},
            ${data.status === "rejected" ? "Factory rejected RMA" : `Factory ${data.status}`},
            ${context.userId}
          )
        `;
      }
    }
    return { ok: true };
  });

export const scrapLot = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((lotId: string) => lotId)
  .handler(async ({ context, data: lotId }) => {
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    const lot = await sql<{ id: string; item_id: string; qty: number; status: string }>`
      select l.id, l.item_id, coalesce(s.qty, 0)::int as qty, l.status
      from lots l
      left join stock s on s.lot_id = l.id and s.location_id = ${ws.locationId}
      where l.id = ${lotId} and l.company_id = ${ws.companyId}
    `;
    if (!lot[0]) throw new Error("Lot not found");
    if (lot[0].status === "in_transit_to_factory") {
      throw new Error("Lot is already on a factory return");
    }
    await sql`
      update lots set status = 'written_off'
      where id = ${lotId} and company_id = ${ws.companyId}
    `;
    await sql`
      update stock set qty = 0
      where lot_id = ${lotId} and company_id = ${ws.companyId}
    `;
    await sql`
      insert into stock_movements (
        id, company_id, item_id, lot_id, location_id, kind, qty, reason, actor_id
      ) values (
        ${nid("mv")}, ${ws.companyId}, ${lot[0].item_id}, ${lotId}, ${ws.locationId},
        'scrap', ${-lot[0].qty}, 'Scrapped (expired or not worth factory freight)', ${context.userId}
      )
    `;
    return { ok: true };
  });

export const sellItem = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    itemId: string;
    qty: number;
    buyerName?: string;
    orderRef?: string;
  }) => ({
    itemId: input.itemId,
    qty: Math.floor(Number(input.qty)),
    buyerName: input.buyerName?.trim() || null,
    orderRef: input.orderRef?.trim() || null,
  }))
  .handler(async ({ context, data }) => {
    if (data.qty <= 0) throw new Error("Quantity must be positive");
    const ws = await requireWorkspace(context.userId);
    const item = await (await getSql())<{ id: string; sku: string }>`
      select id, sku from items where id = ${data.itemId} and company_id = ${ws.companyId}
    `;
    if (!item[0]) throw new Error("SKU not found");
    const note = [data.orderRef, data.buyerName].filter(Boolean).join(" · ") || "Sale";
    const allocations = await takeAvailable({
      companyId: ws.companyId,
      locationId: ws.locationId,
      itemId: data.itemId,
      qty: data.qty,
      actorId: context.userId,
      reason: note,
    });
    return { sku: item[0].sku, allocations };
  });

export const listInOutMoves = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    return sql<{
      id: string;
      kind: string;
      qty: number;
      reason: string | null;
      sku: string;
      name: string;
      lot_code: string;
      created_at: string;
    }>`
      select
        m.id, m.kind, m.qty, m.reason, i.sku, i.name, l.lot_code,
        m.created_at::text as created_at
      from stock_movements m
      join items i on i.id = m.item_id
      join lots l on l.id = m.lot_id
      where m.company_id = ${ws.companyId}
        and m.kind in ('receive', 'sale')
        and coalesce(m.reason, '') <> 'Opening balance'
      order by m.created_at desc
      limit 40
    `;
  });

export const lookupByBarcode = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((barcode: string) => barcode.trim())
  .handler(async ({ context, data: barcode }) => {
    if (!barcode) return { item: null as null, barcode };
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    const rows = await sql<ItemRow>`
      select
        i.id, i.sku, i.name, i.category, i.barcode, i.unit, i.cost::text as cost,
        i.sell_price::text as sell_price,
        i.has_expiry, i.return_to_factory, i.status,
        coalesce(sum(s.qty), 0)::int as on_hand,
        coalesce(sum(s.qty) filter (where l.status in ('ok', 'expiring_soon')), 0)::int as available,
        coalesce(sum(s.qty) filter (where l.status = 'quarantined'), 0)::int as quarantined,
        min(l.expires_at) filter (where coalesce(s.qty, 0) > 0 and l.expires_at is not null) as expires_at
      from items i
      left join lots l on l.item_id = i.id
      left join stock s on s.lot_id = l.id
      where i.company_id = ${ws.companyId} and i.barcode = ${barcode}
      group by i.id
      limit 1
    `;
    return { item: rows[0] ? shapeItem(rows[0]) : null, barcode };
  });

export const postScan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((barcode: string) => barcode.trim())
  .handler(async ({ context, data: barcode }) => {
    if (!barcode) throw new Error("Empty barcode");
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    await sql`
      insert into scan_events (id, company_id, user_id, barcode, consumed)
      values (${nid("sc")}, ${ws.companyId}, ${context.userId}, ${barcode}, false)
    `;
    return { barcode };
  });

export const pullScan = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const ws = await requireWorkspace(context.userId);
    const sql = await getSql();
    const rows = await sql<{ id: string; barcode: string }>`
      select id, barcode from scan_events
      where company_id = ${ws.companyId} and consumed = false
      order by created_at desc
      limit 1
    `;
    if (!rows[0]) return { barcode: null as string | null };
    await sql`
      update scan_events set consumed = true
      where id = ${rows[0].id} and company_id = ${ws.companyId}
    `;
    return { barcode: rows[0].barcode };
  });

function shapeItem(row: ItemRow) {
  return {
    id: row.id,
    sku: row.sku,
    name: row.name,
    category: row.category,
    barcode: row.barcode,
    unit: row.unit,
    cost: Number(row.cost),
    sellPrice: Number(row.sell_price ?? 0),
    hasExpiry: row.has_expiry,
    returnToFactory: row.return_to_factory,
    status: row.status,
    onHand: row.on_hand,
    available: row.available,
    quarantined: row.quarantined,
    expiresAt: row.expires_at ?? null,
    daysLeft: daysUntil(row.expires_at ?? null),
  };
}

async function takeAvailable(opts: {
  companyId: string;
  locationId: string;
  itemId: string;
  qty: number;
  actorId: string;
  reason: string;
}) {
  const sql = await getSql();
  const lots = await sql<{
    id: string;
    lot_code: string;
    expires_at: string | null;
    qty: number;
  }>`
    select l.id, l.lot_code, l.expires_at, coalesce(s.qty, 0)::int as qty
    from lots l
    join stock s on s.lot_id = l.id and s.location_id = ${opts.locationId}
    where l.company_id = ${opts.companyId}
      and l.item_id = ${opts.itemId}
      and l.status in ('ok', 'expiring_soon')
      and s.qty > 0
    order by l.expires_at asc nulls last, l.created_at asc
  `;
  const available = lots.reduce((sum, lot) => sum + lot.qty, 0);
  if (available < opts.qty) {
    throw new Error(`Only ${available} available to sell — not enough good stock`);
  }
  let left = opts.qty;
  const allocations: Array<{ lotCode: string; qty: number; expiresAt: string | null }> = [];
  for (const lot of lots) {
    if (left <= 0) break;
    const take = Math.min(lot.qty, left);
    await sql`
      update stock set qty = qty - ${take}
      where lot_id = ${lot.id} and location_id = ${opts.locationId} and company_id = ${opts.companyId}
    `;
    await sql`
      insert into stock_movements (
        id, company_id, item_id, lot_id, location_id, kind, qty, reason, actor_id
      ) values (
        ${nid("mv")}, ${opts.companyId}, ${opts.itemId}, ${lot.id}, ${opts.locationId},
        'sale', ${-take}, ${opts.reason}, ${opts.actorId}
      )
    `;
    allocations.push({ lotCode: lot.lot_code, qty: take, expiresAt: lot.expires_at });
    left -= take;
  }
  return allocations;
}

function statusFromDate(iso: string): string {
  const d = daysUntil(iso);
  if (d === null) return "ok";
  if (d < 0) return "expired";
  if (d <= 7) return "expiring_soon";
  return "ok";
}

async function upsertStock(companyId: string, lotId: string, locationId: string, delta: number) {
  const sql = await getSql();
  const existing = await sql<{ qty: number }>`
    select qty from stock where lot_id = ${lotId} and location_id = ${locationId}
  `;
  if (existing[0]) {
    await sql`
      update stock set qty = qty + ${delta}
      where lot_id = ${lotId} and location_id = ${locationId} and company_id = ${companyId}
    `;
  } else {
    await sql`
      insert into stock (company_id, lot_id, location_id, qty)
      values (${companyId}, ${lotId}, ${locationId}, ${delta})
    `;
  }
}

async function syncLotStatuses(companyId: string) {
  const sql = await getSql();
  await sql`
    update lots
    set status = 'expired'
    where company_id = ${companyId}
      and expires_at is not null
      and expires_at < current_date
      and status in ('ok', 'expiring_soon')
  `;
  await sql`
    update lots
    set status = 'expiring_soon'
    where company_id = ${companyId}
      and expires_at is not null
      and expires_at >= current_date
      and expires_at <= (current_date + 7)
      and status = 'ok'
  `;
}
