import { getSql, type Sql } from "@/lib/db";
import { nid } from "@/lib/utils";
import { seedCompany } from "@/lib/seed";

export type Workspace = {
  companyId: string;
  companyName: string;
  locationId: string;
  locationName: string;
  role: string;
};

export async function requireWorkspace(userId: string): Promise<Workspace> {
  const sql = await getSql();
  const existing = await sql<{
    company_id: string;
    company_name: string;
    location_id: string;
    location_name: string;
    role: string;
  }>`
    select
      c.id as company_id,
      c.name as company_name,
      l.id as location_id,
      l.name as location_name,
      m.role
    from company_members m
    join companies c on c.id = m.company_id
    join locations l on l.company_id = c.id
    where m.user_id = ${userId}
    order by l.created_at asc
    limit 1
  `;
  if (existing[0]) {
    return {
      companyId: existing[0].company_id,
      companyName: existing[0].company_name,
      locationId: existing[0].location_id,
      locationName: existing[0].location_name,
      role: existing[0].role,
    };
  }
  return createWorkspace(sql, userId);
}

async function createWorkspace(sql: Sql, userId: string): Promise<Workspace> {
  const users = await sql<{ name: string | null; email: string | null }>`
    select name, email from "user" where id = ${userId} limit 1
  `;
  const label = users[0]?.name?.trim() || users[0]?.email?.split("@")[0] || "Demo";
  const companyName = userId === "dev-user" ? "Demo warehouse" : `${label}'s warehouse`;
  const companyId = nid("co");
  const locationId = nid("loc");

  try {
    await sql`
      insert into companies (id, name, created_by, seeded)
      values (${companyId}, ${companyName}, ${userId}, false)
    `;
    await sql`
      insert into company_members (company_id, user_id, role)
      values (${companyId}, ${userId}, 'admin')
    `;
    await sql`
      insert into locations (id, company_id, name)
      values (${locationId}, ${companyId}, 'Main warehouse')
    `;
    await seedCompany(sql, { companyId, locationId, userId });
    await sql`update companies set seeded = true where id = ${companyId}`;
  } catch {
    const raced = await sql<{
      company_id: string;
      company_name: string;
      location_id: string;
      location_name: string;
      role: string;
    }>`
      select
        c.id as company_id,
        c.name as company_name,
        l.id as location_id,
        l.name as location_name,
        m.role
      from company_members m
      join companies c on c.id = m.company_id
      join locations l on l.company_id = c.id
      where m.user_id = ${userId}
      order by l.created_at asc
      limit 1
    `;
    if (raced[0]) {
      return {
        companyId: raced[0].company_id,
        companyName: raced[0].company_name,
        locationId: raced[0].location_id,
        locationName: raced[0].location_name,
        role: raced[0].role,
      };
    }
    throw new Error("Could not create workspace");
  }

  return {
    companyId,
    companyName,
    locationId,
    locationName: "Main warehouse",
    role: "admin",
  };
}
